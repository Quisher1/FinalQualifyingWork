import matplotlib.pyplot as plt
import numpy as np

def parseTrainData(filepath):
    data = []
    with open(filepath, "r") as file:
        for line in file:
            line = line.rstrip()
            line = line.split(' ')
            data.append(float(line[-1]))    
    return data


if __name__ == '__main__':
    Y_train = parseTrainData("./train_log.txt")
    Y_test  = parseTrainData("./test_log.txt")


    X = [i for i in range(len(Y_train))]


    Y_train = np.array(Y_train)
    Y_test  = np.array(Y_test)
    X = np.array(X)

    fig, ax = plt.subplots()

    train_loss = ax.plot(X, Y_train, label='train')
    test_loss  = ax.plot(X, Y_test,  label='test')
    ax.legend()
    #fig.legend((train_loss, test_loss), ("train loss", "test loss"), loc="upper right", ncol=5)

    ax.set_xlabel('эпоха')
    ax.set_ylabel('ошибка')
    plt.show()