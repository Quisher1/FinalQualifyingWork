import torch
import torch.nn as nn

from model_parts import *

from config import MINUTIAES_CLASSES, MASK_CLASSES

class FeatureExtractionUNet(nn.Module):
    def __init__(self, n_channels, n_featuresClasses, n_maskClasses, features=32):
        super(FeatureExtractionUNet, self).__init__()

        self.inc = (DoubleConv(n_channels, features))
        self.down1 = (Down(features, features*2))
        self.down2 = (Down(features*2, features*4))
        self.down3 = (Down(features*4, features*8))
        self.down4 = (Down(features*8, features*16))
        self.up1 = (Up(features*16, features*8))
        self.up2 = (Up(features*8, features*4))
        self.up3 = (Up(features*4, features*2))
        self.up4 = (Up(features*2, features))
        #self.outc = (OutConv(64, n_classes))
        
        self.featuresSegmentation = nn.Sequential(
            ConvLayer(features, n_featuresClasses, use_bn=False, activation_fn='none'),
        )

        middleFeatures = features // 2
        self.maskSegmentation = nn.Sequential(
            ConvLayer(features, middleFeatures, use_bn=True, activation_fn='relu'),
            ConvLayer(middleFeatures, n_maskClasses, use_bn=False, activation_fn='none'),
        )

    def forward(self, x):
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        
        return self.featuresSegmentation(x), self.maskSegmentation(x)

    # def use_checkpointing(self):
    #     self.inc = torch.utils.checkpoint(self.inc)
    #     self.down1 = torch.utils.checkpoint(self.down1)
    #     self.down2 = torch.utils.checkpoint(self.down2)
    #     self.down3 = torch.utils.checkpoint(self.down3)
    #     self.down4 = torch.utils.checkpoint(self.down4)
    #     self.up1 = torch.utils.checkpoint(self.up1)
    #     self.up2 = torch.utils.checkpoint(self.up2)
    #     self.up3 = torch.utils.checkpoint(self.up3)
    #     self.up4 = torch.utils.checkpoint(self.up4)
    #     self.outc = torch.utils.checkpoint(self.outc)


if __name__ == "__main__":
    x = torch.randn((3, 1, 161, 161))
    model = FeatureExtractionUNet(n_channels=1, n_featuresClasses=MINUTIAES_CLASSES, n_maskClasses=MASK_CLASSES, features=64)
    featuresSeg, maskSeg = model(x)
    
    print(featuresSeg.shape)
    print(maskSeg.shape)