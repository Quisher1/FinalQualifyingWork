import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

from OrientationMap import localOrientationMap

if __name__ == '__main__':
    image = cv.imread("./dataset/stiching_test/1.png", cv.IMREAD_GRAYSCALE)

    lom = localOrientationMap(image)

    kernel_size = 31
    sigma = 1

    frequency = 8

    gamma = 0.7
    psi = 0


    mean = np.mean(image)
    borderedImage = cv.copyMakeBorder(image, kernel_size, kernel_size, kernel_size, kernel_size, cv.BORDER_CONSTANT, None, mean)
    borderedImage = np.float32(borderedImage)
    borderedImage /= 255

    image = np.float32(image)
    image /= 255


    half = kernel_size // 2
    
    resultImage = np.zeros_like(image, dtype=np.float32)

    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            cropped = borderedImage[kernel_size + i - half : kernel_size +  i + half + 1, kernel_size +  j - half : kernel_size + j + half + 1]

            theta = 3.141592 / 2 + lom[i, j]

            
            kernel = cv.getGaborKernel((kernel_size, kernel_size), sigma, theta, frequency, gamma, psi)
            result = cv.filter2D(cropped, -1, kernel)

            resultImage[i, j] = np.sum(result)

            # fig, ax = plt.subplots(1, 3)
            # ax[0].imshow(kernel, cmap='gray')
            # ax[1].imshow(cropped)
            # ax[2].imshow(result)
            # plt.show()

    fig, ax = plt.subplots(1, 2)
    ax[0].imshow(image)
    ax[1].imshow(resultImage)
    plt.show()



