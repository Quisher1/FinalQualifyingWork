import torch


def save_checkpoint(state, filename="checkpoint.pth"):
    torch.save(state, filename)
    
def load_checkpoint(checkpoint, model):
    model.load_state_dict(checkpoint['state_dict'])
    
def load_checkpoint2(checkpointFile, model, targetDevice='cpu'):
    checkpoint = torch.load(checkpointFile, map_location=torch.device(targetDevice))
    model.load_state_dict(checkpoint['state_dict'])