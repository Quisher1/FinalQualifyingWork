import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
import scipy
import math

def localOrientationMap(image : cv.Mat, smooth_sigma = 8):
    SobelX = cv.Sobel(image, cv.CV_32FC1, 1, 0)
    SobelY = cv.Sobel(image, cv.CV_32FC1, 0, 1)
    
    Gxx = SobelX * SobelX
    Gyy = SobelY * SobelY
    Gxy = SobelX * SobelY
    
    Gxx = scipy.ndimage.filters.gaussian_filter(Gxx, smooth_sigma)
    Gxy = scipy.ndimage.filters.gaussian_filter(Gxy, smooth_sigma)
    Gyy = scipy.ndimage.filters.gaussian_filter(Gyy, smooth_sigma)
            
    angles = math.pi/2. + np.divide(np.arctan2(np.multiply(Gxy,2), np.subtract(Gxx,Gyy)),2)
    return angles


if __name__ == '__main__':
    image = cv.imread("./dataset/train/images/1.tif", cv.IMREAD_GRAYSCALE)
    plt.imshow(localOrientationMap(image), cmap='gray')
    plt.axis('off')
    plt.show()