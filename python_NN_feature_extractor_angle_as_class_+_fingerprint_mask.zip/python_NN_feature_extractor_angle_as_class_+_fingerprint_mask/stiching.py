import torch
import cv2 as cv
import numpy as np

from UNetModel import FeatureExtractionUNet
from utils import *
from dataset import localOrientationMap

from sklearn import linear_model

def extract(model, image : cv.Mat, lom) -> list:
    assert(len(image.shape) == 2)

    imageWidth  = image.shape[1]
    imageHeight = image.shape[0]

    input = image.copy()
    input = input.astype(np.float32)
    input /= 255

    input = torch.from_numpy(input)
    input = torch.reshape(input, (1, 1, imageHeight, imageWidth))
    
    pred_heatmap, pred_anglesmap = model(input)
    
    pred_heatmap = torch.reshape(pred_heatmap, (imageHeight, imageWidth))
    pred_heatmap = pred_heatmap.cpu()
    pred_heatmap = pred_heatmap.detach().numpy()
    
    pred_anglesmap = torch.reshape(pred_anglesmap, (imageHeight, imageWidth))
    pred_anglesmap = pred_anglesmap.cpu()
    pred_anglesmap = pred_anglesmap.detach().numpy()
    
    threshold = 0
    pred_heatmap[pred_heatmap >  threshold] = 255
    pred_heatmap[pred_heatmap <= threshold] = 0
    pred_heatmap = pred_heatmap.astype(np.uint8)

    contours, _ = cv.findContours(pred_heatmap, cv.RETR_LIST, cv.CHAIN_APPROX_NONE)
    
    points = []
    for c in contours:
        M = cv.moments(c)
        if (M["m00"] == 0):
            continue
        x = int(M["m10"] / M["m00"])
        y = int(M["m01"] / M["m00"])
        #angle = pred_anglesmap[y, x]
        angle = lom[y, x]
        points.append((x, y, angle))
        
    return points


if __name__ == '__main__':
    model = FeatureExtractionUNet(1)
    load_checkpoint2("./checkpoints/checkpoint990.pth", model)

    image1 = cv.imread('./dataset/stiching_test/1.png', cv.IMREAD_GRAYSCALE)
    lom1 = localOrientationMap(image1)
    points1 = extract(model, image1, lom1)
    
    
    image2 = cv.imread('./dataset/stiching_test/2.png', cv.IMREAD_GRAYSCALE)
    lom2 = localOrientationMap(image2)
    points2 = extract(model, image2, lom2)
        
    
    points1 = np.array(points1)
    points2 = np.array(points2)

    
    print(len(points1))
    print(len(points2))


    ransac = linear_model.RANSACRegressor()

    ransac.fit(points1, points2)

    #H, mask = cv.findHomography(points1, points2, 0, 5.0)

    print(H)