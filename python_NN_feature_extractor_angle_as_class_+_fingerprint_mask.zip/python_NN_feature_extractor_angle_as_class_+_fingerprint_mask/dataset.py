from os import listdir
from os.path import join, isfile, isdir
from torch.utils.data import Dataset
from config import *
import cv2 as cv

import numpy as np

import matplotlib.pyplot as plt

import torch

import math
import scipy

import json

def localOrientationMap(image : cv.Mat, smooth_sigma = 8):
    image = image.astype(np.float32)
    
    SobelX = cv.Sobel(image, cv.CV_32FC1, 1, 0)
    SobelY = cv.Sobel(image, cv.CV_32FC1, 0, 1)
    
    Gxx = SobelX * SobelX
    Gyy = SobelY * SobelY
    Gxy = SobelX * SobelY
    
    Gxx = scipy.ndimage.filters.gaussian_filter(Gxx, smooth_sigma)
    Gxy = scipy.ndimage.filters.gaussian_filter(Gxy, smooth_sigma)
    Gyy = scipy.ndimage.filters.gaussian_filter(Gyy, smooth_sigma)
            
    angles = math.pi/2. + np.divide(np.arctan2(np.multiply(Gxy,2), np.subtract(Gxx,Gyy)),2)
    return angles


def parseMinutiaesFile(filepath, width, height):
    minutiaes = []
    with open(filepath, 'r') as file:
        for line in file:
            line = line.rstrip()
            line = line.split(' ')

            x     = float(line[0])
            y     = float(line[1])
            angle = float(line[2])

            x = max(x, 1)
            y = max(y, 1)

            x = min(x, width-1)
            y = min(y, height-1)

            # if (angle > 180):
            #     angle -= 360
            # angle += 180

            minutiaes.append([x, y, angle])
    return minutiaes

def parseMaskFile(filepath, width, height):
    mask = np.zeros((height, width))
    
    with open(filepath) as file:
        data = json.load(file)
        borderPoints = data['shapes'][0]['points']
        borderPoints = np.array(borderPoints, dtype=np.int32)
        borderPoints = np.reshape(borderPoints, (-1, 1, 2))
        cv.fillPoly(mask, [borderPoints], color=(255, 255, 255))
    return mask
        


def createAngleMapsFromMinutiaes(image : cv.Mat, minutiaes : list, numMaps=6, minAngle=0, maxAngle=360):
    maxAngle += 0.0001
    minAngle -= 0.0001

    maxRadius = 4

    angleMaps = np.zeros((numMaps, image.shape[0], image.shape[1]), dtype=np.float32)

    for dx, dy, da in minutiaes:
        k = int(da * numMaps / (maxAngle - minAngle))
        cv.circle(angleMaps[k], (int(dx), int(dy)), maxRadius, (255,255,255), -1)
        
    # for i in range(numMaps):
    #     cv.imshow("map" + str(i), angleMaps[i])
    # cv.waitKey(0)

    return angleMaps



class CustomDataset(Dataset):
    def __init__(self, imageFolder, minutiaesFolder, masksFolder, numClasses, isTraining=False):
        super().__init__()
        self.isTraining = isTraining
        self.numClasses = numClasses
        
        self.imageNameToPath = dict()
        imageFiles = [file for file in listdir(imageFolder) if isfile(join(imageFolder, file))]
        imageNames = []
        for filename in imageFiles:
            name = filename[:filename.rfind('.')]
            imageNames.append(name)
            self.imageNameToPath[name] = join(imageFolder, filename)
        
        self.minutiaesNameToPath = dict()
        minutiaesFiles  = [file for file in listdir(minutiaesFolder) if isfile(join(minutiaesFolder, file))]
        minutiaesNames  = []
        for filename in minutiaesFiles:
            name = filename[:filename.rfind('.')]
            minutiaesNames.append(name)
            self.minutiaesNameToPath[name] = join(minutiaesFolder, name + '.txt')

        self.masksNameToPath = dict()
        masksFiles = [file for file in listdir(masksFolder) if isfile(join(masksFolder, file))]
        masksNames = []
        for filename in masksFiles:
            name = filename[:filename.rfind('.')]
            masksNames.append(name)
            self.masksNameToPath[name] = join(masksFolder, name + '.json')
 
        self.inter = list(set(imageNames).intersection(set(minutiaesNames)).intersection(set(masksNames)))
        self.inter = sorted(self.inter)
        
    
    def __getitem__(self, index):
        name = self.inter[index]
        image      = cv.imread(self.imageNameToPath[name], cv.IMREAD_GRAYSCALE)
        minutiaes  = parseMinutiaesFile(self.minutiaesNameToPath[name], image.shape[1], image.shape[0])
        mask       = parseMaskFile(self.masksNameToPath[name], image.shape[1], image.shape[0])

        transformed = None    
        if self.isTraining:
            transformed = train_transform(image=image, mask=mask, keypoints=minutiaes)
            image     = transformed['image']
            minutiaes = transformed['keypoints']
            mask      = transformed['mask']

        anglesMap = createAngleMapsFromMinutiaes(image, minutiaes, numMaps=self.numClasses)
        
        #anglesMap = localOrientationMap(image, smooth_sigma=8)#, smooth_sigma=4)
        #fig, ax = plt.subplots(1, NUM_CLASSES+1)
        # for i in range(NUM_CLASSES):
        #     ax[i].imshow(anglesMap[i])
        # ax[NUM_CLASSES].imshow(image)
        # plt.show()
        # anglesMap = torch.from_numpy(anglesMap)
        
        transformed = general_transform(image=image)
        image = transformed['image']
        

        anglesMap = torch.from_numpy(anglesMap)
        anglesMap[anglesMap == 255] = 1

        mask = torch.from_numpy(mask)
        mask[mask == 255] = 1
        mask = torch.unsqueeze(mask, 0)
        
        return image.to(torch.float32), anglesMap.to(torch.float32), mask.to(torch.float32)
    
    def __len__(self):
        return len(self.inter)
    


if __name__ == '__main__':
    VAL_IMAGES_FOLDER = "/media/pavel/DATA/cpp_projects/Future/Diplom/python_Delone_Triangulation_+_finger_mask/HQ_result/train/images"
    VAL_MINUTIAES_FOLDER = "/media/pavel/DATA/cpp_projects/Future/Diplom/python_Delone_Triangulation_+_finger_mask/HQ_result/train/minutiaes"
    VAL_MASKS_FOLDER = "/media/pavel/DATA/cpp_projects/Future/Diplom/python_Delone_Triangulation_+_finger_mask/HQ_result/train/masks"

    dataset = CustomDataset(VAL_IMAGES_FOLDER, VAL_MINUTIAES_FOLDER, VAL_MASKS_FOLDER, numClasses=MINUTIAES_CLASSES, isTraining=True)
    
    for image, featuresSeg, maskSeg in dataset:
        print(image.shape)
        image       = torch.squeeze(image, 0) #torch.reshape(image, (INPUT_SIZE, INPUT_SIZE))
        featuresSeg = featuresSeg #torch.reshape(featuresSeg,  (MINUTIAES_CLASSES, INPUT_SIZE, INPUT_SIZE))
        maskSeg     = maskSeg#torch.reshape(maskSeg,  (MASK_CLASSES, INPUT_SIZE, INPUT_SIZE))

        
        print(image.shape)
        print(featuresSeg.shape)
        print(maskSeg.shape)

        image       = image.detach().numpy()
        featuresSeg = featuresSeg.detach().numpy()
        maskSeg     = maskSeg.detach().numpy()
        
        # fig, ax = plt.subplots(1, MINUTIAES_CLASSES + MASK_CLASSES + 1)

        # for i in range(MINUTIAES_CLASSES):
        #     ax[i].imshow(featuresSeg[i])

        # for i in range(MASK_CLASSES):
        #     ax[MINUTIAES_CLASSES+i].imshow(maskSeg[i])

        # ax[MINUTIAES_CLASSES + MASK_CLASSES].imshow(image, cmap='gray')

        fig, ax = plt.subplots(1, 1 + MINUTIAES_CLASSES + MASK_CLASSES)

        ax[0].imshow(image, cmap='gray')

        for i in range(MINUTIAES_CLASSES):
            ax[1 + i].imshow(featuresSeg[i])
        
        for i in range(MASK_CLASSES):
            ax[1 + MINUTIAES_CLASSES + i].imshow(maskSeg[i])

        plt.show()