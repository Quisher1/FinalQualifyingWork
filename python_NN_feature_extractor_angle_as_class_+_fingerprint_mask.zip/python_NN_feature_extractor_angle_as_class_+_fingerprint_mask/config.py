import torch
import albumentations as A
from albumentations.pytorch import ToTensorV2
import numpy as np


INPUT_SIZE           = 192
NUM_THREADS          = 12
BATCH_SIZE           = 8
NUM_EPOCHS           = 500
LEARNING_RATE        = 0.05
LEARNING_RATE_LAMBDA = 0.95  ### lambda epoch: LEARNING_RATE_LAMBDA ** epoch
LAMBDA               = 0.85 # (lambda) * minutiaesLoss + (1 - lambda) * maskLoss

INPUT_CHANNELS    = 1
MINUTIAES_CLASSES = 12
MASK_CLASSES      = 1

TRAIN_IMAGES_FOLDER    = "./dataset/train/images"
TRAIN_MINUTIAES_FOLDER = "./dataset/train/minutiaes"
TRAIN_MASKS_FOLDER     = "./dataset/train/masks"

VAL_IMAGES_FOLDER    = "./dataset/val/images"
VAL_MINUTIAES_FOLDER = "./dataset/val/minutiaes"
VAL_MASKS_FOLDER     = "./dataset/val/masks"


TEST_IMAGES_FOLDER    = None #"./dataset/test/images"
TEST_MINUTIAES_FOLDER = None
TEST_MASKS_FOLDER     = None

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

class Normalize(A.ImageOnlyTransform):
    def __init__(self):
        super().__init__(True, 1.0)

    def apply(self, image, **params):
        return image / 255.0
    

train_transform = A.Compose([
    A.GaussNoise(var_limit=(10, 100)),
    A.RandomRotate90(),
    #A.RandomScale((-0.5, 0.1)),
    A.Rotate(limit=45),
    #A.RandomCrop(width=INPUT_SIZE, height=INPUT_SIZE),
    A.RandomResizedCrop(width=INPUT_SIZE, height=INPUT_SIZE, scale=(0.1, 1), ratio=(1, 1)),
    #A.VerticalFlip(0.5),
    #A.HorizontalFlip(0.5),
    A.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.2, p=1),
],
    keypoint_params=A.KeypointParams(format='xya', angle_in_degrees=True))

general_transform = A.Compose([
    Normalize(),
    ToTensorV2()
])

# test_transform = A.Compose([
#     #A.RandomCrop(width=INPUT_SIZE, height=INPUT_SIZE),
# ])