import numpy as np
import cv2
from absl import app, flags
import math
#import imutils

import os
from os import listdir
from os.path import join, isfile, isdir

IMAGES_PATH = './HQ_result/'


lineLength = 15
lineThickness = 5


minutiaesList = list()


def main(argv):
    def draw_line(event, x, y, flags, param):
        global sx, sy, DRAW, xx, yy
        if event == cv2.EVENT_LBUTTONDOWN:
            DRAW = True
            sx, sy = x, y # save start coordinates
        elif event == cv2.EVENT_MOUSEMOVE:
            if DRAW == None:
                xx = x
                yy = y
        elif event == cv2.EVENT_LBUTTONUP:
            DRAW = False
            angle = math.atan2(yy - sy, xx - sx)
            ex, ey = int(sx + lineLength * math.cos(angle)), int(sy + lineLength * math.sin(angle))

            cv2.circle(img, (sx, sy), int(lineThickness * 1.5), (255, 0, 0), -1)
            cv2.line(img, (sx, sy), (ex, ey), color=(0,0,255),thickness= lineThickness, lineType=cv2.LINE_AA )

            angle = angle * 180 / 3.141592
            if (angle < 0):
                angle += 360

            sx /= ar
            sy /= ar

            minutiaesList.append([int(sx), int(sy), int(angle)])

    
    imagePaths = [join(IMAGES_PATH, file) for file in listdir(IMAGES_PATH) if isfile(join(IMAGES_PATH, file)) and file.lower().endswith(('.bmp', ".png", ".jpeg", ".jpg"))]
    for path in imagePaths:
        print(path)
        image_name = path[path.rfind('/') + 1 : path.rfind('.')]
        img = cv2.imread(path, cv2.IMREAD_GRAYSCALE)

        imageWidth  = img.shape[1]
        imageHeight = img.shape[0]
        target_size = (2300, 1200) # for almost fullscreen displaying

        global ar
        ar = min(target_size[0] / imageWidth, target_size[1] / imageHeight)
        newImageWidth  = int(round(imageWidth  * ar))
        newImageHeight = int(round(imageHeight * ar))

        img = cv2.resize(img, (newImageWidth, newImageHeight))

        cv2.namedWindow('image')
        cv2.setMouseCallback('image', draw_line)
        while True:
            cv2.imshow('image', img)
            k = cv2.waitKey(1) & 0xFF
            if k ==ord('q'):
                break
                cv2.destroyAllWindows()

        with open(join(IMAGES_PATH, image_name + ".txt"), 'w') as file:
            for m in minutiaesList:
                file.write(f'{m[0]} {m[1]} {m[2]}\n')
        minutiaesList.clear()

if __name__=='__main__':
   app.run(main)
