import torch
import torch.nn as nn
from torch import optim

from tqdm import tqdm

from config import *

from torch.utils.data import DataLoader
from dataset import CustomDataset

from UNetModel import FeatureExtractionUNet, weights_init

from utils import *

from loss import *

import matplotlib.pyplot as plt
import torch.nn.functional as F

import os
from os.path import join
import shutil
import errno

def rmdir(folder):
    shutil.rmtree(folder, ignore_errors=True)

def mkdir(folder):
    try:
        os.mkdir(folder)
    except OSError as exc:
        if exc.errno != errno.EEXIST:
            raise
        pass

fig, ax = plt.subplots(2, MINUTIAES_CLASSES + MASK_CLASSES + 1)

def train_fn(model, dataloader, optimizer, CE_loss, BCE_loss, gradScaler):
    running_loss = 0
    for image, featuresSeg, maskSeg in tqdm(dataloader):
        image       = image.to(DEVICE)
        featuresSeg = featuresSeg.to(DEVICE)
        maskSeg     = maskSeg.to(DEVICE)

        with torch.autocast(DEVICE.type if DEVICE.type != 'mps' else 'cpu', enabled=False):
            pred_featuresSeg, pred_maskSeg = model(image)
            features_ce_loss   = CE_loss(pred_featuresSeg, featuresSeg)
            features_dice_loss = dice_loss_fn(torch.sigmoid(pred_featuresSeg), featuresSeg, multiclass=True if MINUTIAES_CLASSES > 1 else False)
            features_loss = features_dice_loss + features_ce_loss

            mask_bce_loss  = BCE_loss(pred_maskSeg, maskSeg)
            if MASK_CLASSES == 1:
                pred_maskSeg = torch.squeeze(pred_maskSeg)
                maskSeg      = torch.squeeze(maskSeg)
            if (len(pred_maskSeg.shape) == 2):
                pred_maskSeg = torch.unsqueeze(pred_maskSeg, dim=0)
            if (len(maskSeg.shape) == 2):
                maskSeg = torch.unsqueeze(maskSeg, dim=0)
            mask_dice_loss = dice_loss_fn(torch.sigmoid(pred_maskSeg), maskSeg, multiclass=True if MASK_CLASSES > 1 else False)
            mask_loss = mask_dice_loss + mask_bce_loss

            loss = LAMBDA * features_loss + (1 - LAMBDA) * mask_loss

        optimizer.zero_grad(set_to_none=True)
        gradScaler.scale(loss).backward()
        gradScaler.unscale_(optimizer)
        torch.nn.utils.clip_grad.clip_grad_norm_(model.parameters(), 1.0)
        gradScaler.step(optimizer)
        gradScaler.update()

        running_loss += loss.item()
    
    return running_loss / len(dataloader)


def test_fn(model, dataloader, epoch):
    running_loss = 0
    with torch.no_grad():
        for i, (image, featuresSeg, maskSeg) in enumerate(tqdm(dataloader)):
            image       = image.to(DEVICE)
            featuresSeg = featuresSeg.to(DEVICE)
            maskSeg     = maskSeg.to(DEVICE)

            pred_featuresSeg, pred_maskSeg = model(image)

            features_ce_loss  = CE_loss(pred_featuresSeg, featuresSeg)
            features_dice_loss = dice_loss_fn(torch.sigmoid(pred_featuresSeg), featuresSeg, multiclass=True if MINUTIAES_CLASSES > 1 else False)
            featurs_loss = features_dice_loss + features_ce_loss

            mask_bce_loss  = BCE_loss(pred_maskSeg, maskSeg)
            if MASK_CLASSES == 1:
                pred_maskSeg = torch.squeeze(pred_maskSeg)
                maskSeg      = torch.squeeze(maskSeg)
            #print(pred_maskSeg.shape, maskSeg.shape)

            if (len(pred_maskSeg.shape) == 2):
                pred_maskSeg = torch.unsqueeze(pred_maskSeg, dim=0)
            if (len(maskSeg.shape) == 2):
                maskSeg = torch.unsqueeze(maskSeg, dim=0)
            
            mask_dice_loss = dice_loss_fn(torch.sigmoid(pred_maskSeg), maskSeg, multiclass=True if MASK_CLASSES > 1 else False)
            mask_loss = mask_dice_loss + mask_bce_loss
            
            loss = LAMBDA * featurs_loss + (1 - LAMBDA) * mask_loss
            running_loss += loss.item()
            
            if (i == 0):
                image            = image[0].detach().to(torch.device('cpu'))
                image            = torch.squeeze(image, 0)
                #image            = torch.squeeze(image, 0)                
                image            = image.detach().numpy()

                featuresSeg      = featuresSeg[0].detach().to(torch.device('cpu'))
                #featuresSeg      = torch.squeeze(featuresSeg, 0)
                #featuresSeg      = torch.squeeze(featuresSeg, 0)
                featuresSeg      = featuresSeg.detach().numpy()

                maskSeg          = maskSeg[0].detach().to(torch.device('cpu'))
                if len(maskSeg.shape) == 2:
                    maskSeg = torch.unsqueeze(maskSeg, 0)
                #maskSeg          = torch.squeeze(maskSeg, 0)
                #maskSeg          = torch.squeeze(maskSeg, 0)
                maskSeg          = maskSeg.detach().numpy()

                pred_featuresSeg = pred_featuresSeg[0].detach().to(torch.device('cpu'))
                #pred_featuresSeg = torch.squeeze(pred_featuresSeg, 0)
                #pred_featuresSeg = torch.squeeze(pred_featuresSeg, 0)
                pred_featuresSeg = pred_featuresSeg.detach().numpy()

                pred_maskSeg     = pred_maskSeg[0].detach().to(torch.device('cpu'))
                if len(pred_maskSeg.shape) == 2:
                    pred_maskSeg = torch.unsqueeze(pred_maskSeg, 0)
                #pred_maskSeg     = torch.squeeze(pred_maskSeg, 0)
                #pred_maskSeg     = torch.squeeze(pred_maskSeg, 0)                
                pred_maskSeg     = pred_maskSeg.detach().numpy()

                
                #ax[0, 0].imshow(image)
                for i in range(MINUTIAES_CLASSES):
                    ax[0, i].imshow(featuresSeg[i])
                    ax[1, i].imshow(pred_featuresSeg[i])
                for i in range(MASK_CLASSES):
                    ax[0, MINUTIAES_CLASSES + i].imshow(maskSeg[i])
                    ax[1, MINUTIAES_CLASSES + i].imshow(pred_maskSeg[i])
                ax[0, MINUTIAES_CLASSES + MASK_CLASSES].imshow(image)
                plt.axis('off')
                plt.savefig(join(SAVED_IMAGES, str(epoch)))
                
    return running_loss / len(dataloader)
        

if __name__ == '__main__':

    SAVED_IMAGES = "./saved_images"
    rmdir(SAVED_IMAGES)
    mkdir(SAVED_IMAGES)

    CHECKPOINTS_FOLDER = "./checkpoints"
    rmdir(CHECKPOINTS_FOLDER)
    mkdir(CHECKPOINTS_FOLDER)

    train_dataset    = CustomDataset(TRAIN_IMAGES_FOLDER, TRAIN_MINUTIAES_FOLDER, TRAIN_MASKS_FOLDER, numClasses=MINUTIAES_CLASSES, isTraining=True)
    train_dataloader = DataLoader(train_dataset, batch_size=BATCH_SIZE, shuffle=True, num_workers=NUM_THREADS)
    
    test_dataset    = CustomDataset(VAL_IMAGES_FOLDER, VAL_MINUTIAES_FOLDER, VAL_MASKS_FOLDER, numClasses=MINUTIAES_CLASSES, isTraining=False)
    test_dataloader = DataLoader(test_dataset, batch_size=1, shuffle=True, num_workers=NUM_THREADS)
    
    N = len(train_dataset)
    
    model = FeatureExtractionUNet(n_channels=1, n_featuresClasses=MINUTIAES_CLASSES, n_maskClasses=MASK_CLASSES, features=64).to(DEVICE)
    for layer in model.children():
        weights_init(layer)


    #optimizer = optim.Adam(model.parameters(), LEARNING_RATE, weight_decay=1e-4)
    #optimizer = optim.RMSprop(model.parameters(), LEARNING_RATE, weight_decay=1e-2, momentum=0.9, foreach=True)
    optimizer = optim.SGD(model.parameters(), LEARNING_RATE, momentum=0.9, weight_decay=1e-4)
    BCE_loss  = nn.BCEWithLogitsLoss()
    CE_loss   = nn.CrossEntropyLoss()
    #criterion = DiceBCELoss()
    #criterion = nn.CrossEntropyLoss()
    #criterion = IoULoss()
    
    lambdaLR  = lambda epoch: LEARNING_RATE_LAMBDA ** epoch
    scheduler = optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambdaLR)
    #scheduler = optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.6, last_epoch=-1)
    #scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'max', patience=5)

    gradScaler = torch.cuda.amp.grad_scaler.GradScaler(enabled=False)
    
    trainLogFile = open("train_log.txt", 'w')
    testLogFile  = open("test_log.txt", 'w')

    print("Device:", DEVICE)

    train_losses = []
    val_losses   = []
    for epoch in range(NUM_EPOCHS):
        print("epoch:", epoch)
        model.train()
        running_loss = train_fn(model, train_dataloader, optimizer, CE_loss=CE_loss, BCE_loss=BCE_loss, gradScaler=gradScaler)
        trainLogFile.write(f"{epoch} : {running_loss}\n")
        trainLogFile.flush()
        scheduler.step()
        print("learning rate:", optimizer.param_groups[0]["lr"])
        if (epoch) % 5 == 0:
            checkpoint = {
                "state_dict" : model.state_dict(),
                "optimizer" : optimizer.state_dict()
            }
            save_checkpoint(checkpoint, join(CHECKPOINTS_FOLDER, f"checkpoint{epoch}.pth"))
        
        print("train loss", running_loss)
        train_losses.append(running_loss)

        model.eval()

        test_loss = test_fn(model, test_dataloader, epoch)
        testLogFile.write(f"{epoch} : {test_loss}\n")
        testLogFile.flush()
        print("val loss: ", test_loss)
        val_losses.append(test_loss)
        print()  
    trainLogFile.close()
    testLogFile.close()

    print("train losses:")
    print(train_losses)

    print("val losses:")
    print(val_losses)

    plt.close('all')
