import torch
import torch.functional as F
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt

from utils import *
from UNetModel import FeatureExtractionUNet
from dataset import CustomDataset, localOrientationMap
from config import *

import numpy as np

import cv2 as cv

import math

from datetime import datetime

def extract(model, image : cv.Mat) -> list:
    assert(len(image.shape) == 2)

    imageWidth  = image.shape[1]
    imageHeight = image.shape[0]

    input = image.copy()
    input = input.astype(np.float32)
    input /= 255

    input = torch.from_numpy(input)
    input = torch.reshape(input, (1, 1, imageHeight, imageWidth))
    
    pred_featuresSeg, pred_maskSeg = model(input)
    
    
    pred_featuresSeg = torch.reshape(pred_featuresSeg, (MINUTIAES_CLASSES, imageHeight, imageWidth))
    pred_featuresSeg = pred_featuresSeg.cpu()
    pred_featuresSeg = pred_featuresSeg.detach().numpy()

    pred_maskSeg = torch.reshape(pred_maskSeg, (MASK_CLASSES, imageHeight, imageWidth))
    flat = torch.flatten(pred_maskSeg)
    flat = flat[flat > 1]

    medianValue, medianIndex = torch.median(flat, dim=0)
    medianValue = medianValue.item()

    stdValue = 0
    diff     = torch.pow(flat - medianValue, 2)
    stdValue = torch.sqrt((1 / (diff.shape[0] - 1)) * torch.sum(diff, dim=0))
    stdValue = stdValue.item()

    print(medianValue - stdValue, medianValue + stdValue)
    flat = flat.detach().numpy()
    pred_maskSeg = pred_maskSeg.cpu()
    pred_maskSeg = pred_maskSeg.detach().numpy()



    mask = pred_maskSeg[0].copy()
    threshold = medianValue - stdValue
    mask[mask > threshold]  = 255
    mask[mask <= threshold] = 0

    mask = np.uint8(mask)
    mask = cv.GaussianBlur(mask, (31, 31), 1.0)
    ret, thresh = cv.threshold(mask, 127, 255, 0)
    contours, hierarchy = cv.findContours(thresh, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
    c = max(contours, key = cv.contourArea)
    print(c)
    mask2 = np.zeros_like(mask)
    #cv.drawContours(mask2, c, -1, (255, 255, 255), -1)
    cv.fillPoly(mask2, pts =[c], color=(255,255,255))
    #cv.imshow("mask2", mask2)
    #cv.waitKey(0)

    mask = mask2


#    print(flat.tolist())

    fig, ax = plt.subplots(1, 4)
    ax[0].imshow(image)
    ax[1].imshow(mask)
    ax[2].imshow(pred_maskSeg[0])
    ax[3].hist(flat, bins=255)
    plt.show()
    
    
    allMinutiaesHeatmap = np.zeros((pred_featuresSeg.shape[1], pred_featuresSeg.shape[2]), dtype=np.uint8)

    for i in range(allMinutiaesHeatmap.shape[0]):
        for j in range(allMinutiaesHeatmap.shape[1]):
            sum = 0.0
            for k in range(MINUTIAES_CLASSES):
                v = pred_featuresSeg[k, i, j]
                if v > sum:
                    sum = v
            allMinutiaesHeatmap[i, j] = 255 if sum > 0 else 0

    fig, ax = plt.subplots(1, MINUTIAES_CLASSES + MASK_CLASSES + 1)
    for i in range(MINUTIAES_CLASSES):
        layer = pred_featuresSeg[i]
        #layer[layer < 0] = 0
        ax[i].imshow(layer, cmap='gray')

    for i in range(MASK_CLASSES):
        ax[MINUTIAES_CLASSES + i].imshow(pred_maskSeg[i], cmap='gray')

    ax[MINUTIAES_CLASSES + MASK_CLASSES].imshow(allMinutiaesHeatmap, cmap='gray')
    plt.show()

    points = []
    contours, _ = cv.findContours(allMinutiaesHeatmap, cv.RETR_LIST, cv.CHAIN_APPROX_NONE)
    for c in contours:
        M = cv.moments(c)
        if (M["m00"] == 0):
            continue
        x = int(M["m10"] / M["m00"])
        y = int(M["m01"] / M["m00"])

        vecX = 0
        vecY = 0
        count = 0
        for k in range(MINUTIAES_CLASSES):
            v = pred_featuresSeg[k, y, x]
            if v > 0:
                angleRad = (2 * math.pi * (k + 0.5) / MINUTIAES_CLASSES)
                vecX += math.cos(angleRad) * v
                vecY += math.sin(angleRad) * v
                count += 1
        if count == 0:
            continue
        vecX /= count
        vecY /= count

        angle = math.atan2(vecY, vecX)
        points.append((x, y, angle))
        
    return points


if __name__ == '__main__':
    model = FeatureExtractionUNet(INPUT_CHANNELS, MINUTIAES_CLASSES, MASK_CLASSES, features=64)
    load_checkpoint2("./checkpoints/checkpoint495.pth", model, targetDevice=torch.device('cpu'))
    model = model
    

    #image1 = cv.imread('/media/pavel/DATA/DATASETS/PavelKushnarevFingerScans/Pavel_Kushnarev_LI.bmp', cv.IMREAD_GRAYSCALE)
    image1 = cv.imread("/media/pavel/DATA/cpp_projects/Future/Diplom/python_NN_feature_extractor_angle_as_class_+_fingerprint_mask/dataset/val/images/airsnap_1.png", cv.IMREAD_GRAYSCALE)
    
    #image1 = cv.imread('./result2.png', cv.IMREAD_GRAYSCALE)
    #lom1 = localOrientationMap(image1)
    start=datetime.now()
    points1 = extract(model, image1)
    print(datetime.now()-start)
    
    
    image2 = cv.imread('/media/pavel/DATA/DATASETS/FVC_UNI/Images/00006_11.bmp', cv.IMREAD_GRAYSCALE)
    # lom2 = localOrientationMap(image2)
    start   = datetime.now()
    points2 = extract(model, image2)
    print(datetime.now()-start)
        
    
    # points1 = np.array(points1)

    lineColor = (0, 0, 0, 255)

    r = 10
    for x, y, a in points1:
        cv.circle(image1, (int(x), int(y)), 6, (0, 0, 0), -1)
        cv.circle(image1, (int(x), int(y)), 4, (255, 255, 255), -1)
        cv.line(image1, (int(x), int(y)), (int(x + r*math.cos(a)), int(y+r*math.sin(a))), lineColor, 2)

    image1 = cv.resize(image1, (image1.shape[1]*2, image1.shape[0]*2))
    cv.imshow("image1", image1)
    #cv.waitKey(0)



    for x, y, a in points2:
        cv.circle(image2, (int(x), int(y)), 6, (0, 0, 0), -1)
        cv.circle(image2, (int(x), int(y)), 4, (255, 255, 255), -1)
        cv.line(image2, (int(x), int(y)), (int(x + r*math.cos(a)), int(y+r*math.sin(a))), lineColor, 2)

    image2 = cv.resize(image2, (image2.shape[1]*2, image2.shape[0]*2))
    cv.imshow("image2", image2)
    cv.waitKey(0)
    
    
    #print(points1)
    
    
    # t = cv.findHomography(points1, points2, cv.RANSAC)
    
    # print(t)    
    # test_dataset    = CustomTestDataset(TEST_IMAGES_FOLDER)
    # test_dataloader = DataLoader(test_dataset, batch_size=1, num_workers=1)
    
    # for image in test_dataloader:
    #     pred = model(image)
    #     image = torch.squeeze(image, 0)
    #     image = torch.squeeze(image, 0)
    
    #     pred = torch.squeeze(pred, 0)
    #     pred = torch.squeeze(pred, 0)
    #     image = image.detach().numpy()
    #     pred  = pred.detach().numpy()
        
    #     fig, ax = plt.subplots(2)
    #     ax[0].imshow(image)
    #     ax[1].imshow(pred)

    #     plt.show()
    #     plt.close('all')