import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

def alignImagesUsingOpticalFlow(sourceImage : cv.Mat, targetImage : cv.Mat):
    preset = cv.DISOPTICAL_FLOW_PRESET_MEDIUM #cv.DISOPTICAL_FLOW_PRESET_MEDIUM

    patch_size   = 31
    patch_stride = 1

    DIS_flow = cv.DISOpticalFlow.create(preset)
    DIS_flow.setPatchSize(patch_size)
    DIS_flow.setPatchStride(patch_stride)

    flow = np.zeros((targetImage.shape[0], targetImage.shape[1]), dtype=np.float32)



    flow = DIS_flow.calc(targetImage, sourceImage, None)
    flowSplitX, flowSplitY = cv.split(flow)


    #flowSplitX = cv.medianBlur(flowSplitX, 5)
    # flowSplitX = cv.medianBlur(flowSplitX, 5)
    # flowSplitX = cv.medianBlur(flowSplitX, 5)

    #flowSplitY = cv.medianBlur(flowSplitY, 5)
    # flowSplitY = cv.medianBlur(flowSplitY, 5)
    # flowSplitY = cv.medianBlur(flowSplitY, 5)

    #fig, ax = plt.subplots(1, 3)
    ## ax[0].imshow(flowSplitX)
    ## ax[1].imshow(flowSplitY)
    ##plt.show()

    #ax[0].imshow(sourceImage, cmap='gray')
    #ax[1].imshow(targetImage, cmap='gray')
    

    width  =  targetImage.shape[1]
    height =  targetImage.shape[0]
    maxX   = width  - 1
    maxY   = height - 1

    resultImage = np.zeros((height, width), dtype=np.uint8)

    for y in range(height):
        for x in range(width):
            value = targetImage[y, x]

            imgXf = x + flowSplitX[y, x]
            imgYf = y + flowSplitY[y, x]

            if imgXf >= 0 and imgYf >= 0:
                imgX = int(imgXf)
                imgY = int(imgYf)

                if imgX < maxX and imgY < maxY:
                    k2x = imgXf - imgX
                    k2y = imgYf - imgY

                    k1x = 1.0 - k2x
                    k1y = 1.0 - k2y

                    u00 = sourceImage[imgY,     imgX]
                    u10 = sourceImage[imgY,     imgX + 1]
                    u01 = sourceImage[imgY + 1, imgX]
                    u11 = sourceImage[imgY + 1, imgX + 1]

                    value = int(k1y * (k1x * u00 + k2x * u10) + \
                                k2y * (k1x * u01 + k2x * u11) + 0.5)

                elif imgX < width and imgY < height:
                    value = sourceImage[imgY, imgX]
            
            resultImage[y, x] = value
    
    #ax[2].imshow(resultImage, cmap='gray')
    #plt.show()

    return resultImage, flowSplitX, flowSplitY
                    


if __name__ == '__main__':
    image1 = cv.imread("./stitching_test/16/00041_04.bmp", cv.IMREAD_GRAYSCALE)
    image2 = cv.imread("./stitching_test/16/00041_05.bmp", cv.IMREAD_GRAYSCALE)

    k = 1
    image1 = cv.resize(image1, (int(image1.shape[1]/k), int(image1.shape[0]/k)))
    image2 = cv.resize(image2, (int(image2.shape[1]/k), int(image2.shape[0]/k)))

    result, fx, fy = alignImagesUsingOpticalFlow(image1, image2)

    fig, ax = plt.subplots(1, 2)

    ax[0].imshow(result, cmap='gray')

    imageWidth  = result.shape[1]
    imageHeight = result.shape[0]

    print(imageWidth, imageHeight)

    # x, y = np.meshgrid(np.linspace(0, imageWidth,  imageWidth),
    #                    np.linspace(0, imageHeight, imageHeight))
    
    # print(x.shape)
    # print(y.shape)
    # skip = 6
    # u = np.zeros((imageWidth * imageHeight ))
    # v = np.zeros((imageWidth * imageHeight ))

    # for i in range(0, imageHeight, skip):
    #     for j in range(0, imageWidth, skip):
    #         u[i * imageWidth + j] = fx[imageHeight - i - 1, j] #x
    #         v[i * imageWidth + j] = fy[imageHeight - i - 1, j] #y

    

    skip = 6
    newWidth  = imageWidth  // skip
    newHeight = imageHeight // skip

    x, y = np.meshgrid(np.linspace(0, newWidth,  newWidth),
                       np.linspace(0, newHeight, newHeight))
    

    u = np.zeros((newWidth * newHeight))
    v = np.zeros((newWidth * newHeight))

    print(newHeight, newWidth)
    for i in range(newHeight - 1):
        for j in range(newWidth - 1):
            yy = (newHeight - i - 1) * skip
            xx = j * skip
            u[i * newWidth + j] = fx[yy, xx] #x
            v[i * newWidth + j] = fy[yy, xx] #y
    
    
    # Plotting Vector Field with QUIVER 
    ax[1].quiver(x, y, u, v, color='black', scale_units='xy', scale=25) 
    #plt.title('Vector Field') 
    
    # # Setting x, y boundary limits 
    # ax[1].xlim(0, imageWidth) 
    # ax[1].ylim(0, imageHeight) 
    
    # Show plot with grid 
    ax[1].grid() 
    plt.show() 