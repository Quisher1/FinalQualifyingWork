import torch

INPUT_CHANNELS    = 1
MINUTIAES_CLASSES = 12
MASK_CLASSES      = 1

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')