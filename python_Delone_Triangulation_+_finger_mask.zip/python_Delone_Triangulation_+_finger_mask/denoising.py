import matplotlib.pyplot as plt

from skimage.restoration import denoise_wavelet, estimate_sigma
from skimage import data, img_as_float
from skimage.util import random_noise
from skimage.metrics import peak_signal_noise_ratio

import cv2 as cv
import numpy as np

sourceImage = cv.imread("./3HQ/1.png", cv.IMREAD_GRAYSCALE)

clahe = cv.createCLAHE(clipLimit=5)
finalImage = clahe.apply(sourceImage)

sourceImage = finalImage.copy()

imageWidth  = sourceImage.shape[1]
imageHeight = sourceImage.shape[0]

sourceImage = cv.resize(sourceImage, (imageWidth // 2, imageHeight // 2))

imageWidth  = sourceImage.shape[1]
imageHeight = sourceImage.shape[0]


blurred = cv.GaussianBlur(sourceImage, (25, 25), 0.0)

result = np.zeros_like(sourceImage, dtype=np.uint8)

result = 128 + sourceImage - blurred
result[result < 0] = 0
result[result > 255] = 255


# for i in range(imageHeight):
#     for j in range(imageWidth):
#         value = 128 + sourceImage[i, j] - blurred[i, j]
#         if value < 0:
#             value = 0
#         elif value > 255:
#             value = 255
#         result[i, j] = value

#cv.imshow("result", result)
# cv.waitKey(0)
        

minImage = sourceImage.copy()
maxImage = sourceImage.copy()

blockSize = 8
minThreshold = int(0.2 * (1 + 2 * blockSize) * (1 + 2 * blockSize))
maxThreshold = int(0.3 * (1 + 2 * blockSize) * (1 + 2 * blockSize))


for y in range(blockSize, imageHeight - blockSize):
    for x in range(blockSize, imageWidth - blockSize):
        levels = [0] * 256 #num grayscale pixel values
        for dy in range(-blockSize, blockSize+1, 1):
            for dx in range(-blockSize, blockSize+1, 1):
                levels[sourceImage[y + dy, x + dx]] += 1
        
        minValue = 0
        minSum = 0
        while minValue < 255:
            minSum += levels[minValue]
            if (minSum >= minThreshold):
                break
            minValue += 1
        
        maxValue = 255
        maxSum = 0
        while maxValue > 0:
            maxSum += levels[maxValue]
            if maxSum >= maxThreshold:
                break
            maxValue -= 1

        minImage[y, x] = minValue
        maxImage[y, x] = maxValue

#cv.imshow("maxImage", maxImage)
#cv.imshow("minImage", minImage)
# cv.waitKey(0)

result2 = np.zeros_like(sourceImage, dtype=np.uint8)

for i in range(imageHeight):
    for j in range(imageWidth):
        valueSource = sourceImage[i, j]
        valueMin    = minImage[i, j]
        valueMax    = maxImage[i, j]

        if (valueMax <= valueMin):
            valueMin -= 1
        
        value = 0
        if valueSource > valueMin:
            if valueSource < valueMax:
                value = (valueSource - valueMin) * 255 / (valueMax - valueMin)
            else:
                value = 255
        
        result2[i, j] = value


# result2 = cv.GaussianBlur(result2, (3, 3), 0)
# result2 = cv.blur(result2, (2, 2))#

# result2 = cv.medianBlur(result2, 3)


#name = file[file.rfind('/')+1:]

#cv.imshow("result2", result2)
#cv.imwrite(join(RESULT_PATH, name), result2)
#print(join(RESULT_PATH, name))



original = result2#img_as_float(data.chelsea()[100:250, 50:300])

original = cv.cvtColor(original, cv.COLOR_GRAY2RGB)


sigma = 0.12
noisy = original#random_noise(original, var=sigma**2)

fig, ax = plt.subplots(nrows=2, ncols=3, figsize=(8, 5), sharex=True, sharey=True)

plt.gray()

# Estimate the average noise standard deviation across color channels.
sigma_est = estimate_sigma(noisy, channel_axis=-1, average_sigmas=True)
# Due to clipping in random_noise, the estimate will be a bit smaller than the
# specified sigma.
print(f'Estimated Gaussian noise standard deviation = {sigma_est}')

im_bayes = denoise_wavelet(
    noisy,
    channel_axis=-1,
    convert2ycbcr=True,
    method='BayesShrink',
    mode='soft',
    rescale_sigma=True,
)
im_visushrink = denoise_wavelet(
    noisy,
    channel_axis=-1,
    convert2ycbcr=True,
    method='VisuShrink',
    mode='soft',
    sigma=sigma_est,
    rescale_sigma=True,
)

# VisuShrink is designed to eliminate noise with high probability, but this
# results in a visually over-smooth appearance.  Repeat, specifying a reduction
# in the threshold by factors of 2 and 4.
im_visushrink2 = denoise_wavelet(
    noisy,
    channel_axis=-1,
    convert2ycbcr=True,
    method='VisuShrink',
    mode='soft',
    sigma=sigma_est / 2,
    rescale_sigma=True,
)
im_visushrink4 = denoise_wavelet(
    noisy,
    channel_axis=-1,
    convert2ycbcr=True,
    method='VisuShrink',
    mode='soft',
    sigma=sigma_est / 4,
    rescale_sigma=True,
)

# Compute PSNR as an indication of image quality
psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr_bayes = peak_signal_noise_ratio(original, im_bayes)
psnr_visushrink = peak_signal_noise_ratio(original, im_visushrink)
psnr_visushrink2 = peak_signal_noise_ratio(original, im_visushrink2)
psnr_visushrink4 = peak_signal_noise_ratio(original, im_visushrink4)

ax[0, 0].imshow(noisy)
ax[0, 0].axis('off')
ax[0, 0].set_title(f'Noisy\nPSNR={psnr_noisy:0.4g}')
ax[0, 1].imshow(im_bayes)
ax[0, 1].axis('off')
ax[0, 1].set_title(f'Wavelet denoising\n(BayesShrink)\nPSNR={psnr_bayes:0.4g}')
ax[0, 2].imshow(im_visushrink)
ax[0, 2].axis('off')
ax[0, 2].set_title(
    'Wavelet denoising\n(VisuShrink, $\\sigma=\\sigma_{est}$)\n'
    'PSNR=%0.4g' % psnr_visushrink
)
ax[1, 0].imshow(original)
ax[1, 0].axis('off')
ax[1, 0].set_title('Original')
ax[1, 1].imshow(im_visushrink2)
ax[1, 1].axis('off')
ax[1, 1].set_title(
    'Wavelet denoising\n(VisuShrink, $\\sigma=\\sigma_{est}/2$)\n'
    'PSNR=%0.4g' % psnr_visushrink2
)
ax[1, 2].imshow(im_visushrink4)
ax[1, 2].axis('off')
ax[1, 2].set_title(
    'Wavelet denoising\n(VisuShrink, $\\sigma=\\sigma_{est}/4$)\n'
    'PSNR=%0.4g' % psnr_visushrink4
)
fig.tight_layout()

plt.show()