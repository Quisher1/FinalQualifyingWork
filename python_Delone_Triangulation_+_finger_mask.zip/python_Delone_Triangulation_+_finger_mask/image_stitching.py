import torch
from torch.nn import functional as F
import cv2 as cv
import matplotlib.pyplot as plt


import os
from os import listdir
from os.path import join, isfile, isdir

import math
import random
import numpy as np

from config import *


from UNetModel import FeatureExtractionUNet, load_checkpoint
from matching import TriangleExtractor, TrianglesMatcher
from stitching_utils import *
from BFS import maximumValuePath

from test import GaussianSmoothing

from OpticalFlow import alignImagesUsingOpticalFlow

def preprocessing(image : cv.Mat):
    imageWidth  = image.shape[1]
    imageHeight = image.shape[0]

    preprocessed_input = image.copy()
    preprocessed_input = preprocessed_input.astype(np.float32)

    preprocessed_input = torch.from_numpy(preprocessed_input)
    preprocessed_input = torch.reshape(preprocessed_input, (INPUT_CHANNELS, imageHeight, imageWidth))
    preprocessed_input /= 255
    return preprocessed_input


def featureExtraction(model : FeatureExtractionUNet, images : list, absoluteMaskThreshold : float = 1, minutiaesThreshold : float = 0) -> list:
    modelDevice = next(model.parameters()).device

    maxWidth  = 0
    maxHeight = 0
    for image in images:
        if maxWidth < image.shape[1]:
            maxWidth = image.shape[1]
        if maxHeight < image.shape[0]:
            maxHeight = image.shape[0]
        # cv.imshow("image", image)
        # cv.waitKey(0)
    
    batch = []
    batchSize = 0
    vertices = []

    for i, image in enumerate(images):
        left, right, top, bottom = 0, 0, 0, 0
        if maxWidth - image.shape[1] > 0:
            left  = (maxWidth - image.shape[1]) // 2
            right = (maxWidth - image.shape[1]) - left
        if maxHeight - image.shape[0] > 0:
            top    = (maxHeight - image.shape[0]) // 2
            bottom = (maxHeight - image.shape[0]) - top
        resultImage = cv.copyMakeBorder(image, top, bottom, left, right, cv.BORDER_CONSTANT, None, (0, 0, 0, 255))
        vertices.append([(left,                     top),
                         (left + image.shape[1],    top),
                         (left + image.shape[1],    top + image.shape[0]),
                         (left,                     top + image.shape[0])])
        batch.append(preprocessing(resultImage))
        batchSize += 1

    batch = torch.stack(batch, dim=0)
    batch = batch.to(modelDevice)

    pred_featuresSeg, pred_maskSeg = model(batch)
    pred_featuresSeg = pred_featuresSeg.to(torch.device('cpu'))
    pred_maskSeg     = pred_maskSeg.to(torch.device('cpu'))

    # CHANNLES    = pred_featuresSeg.shape[1]
    # KERNEL_SIZE = 17
    # PADDING     = (KERNEL_SIZE - 1) // 2
    # smoothing = GaussianSmoothing(CHANNLES, KERNEL_SIZE, 1)
    # pred_featuresSeg = F.pad(pred_featuresSeg, (PADDING, PADDING, PADDING, PADDING), mode='reflect')
    # pred_featuresSeg = smoothing(pred_featuresSeg)


    batchFeatures = []
    batchMasks    = []
    for batchIndex in range(batchSize):
        batchMask = pred_maskSeg[batchIndex, 0]
        batchMask = batchMask[vertices[batchIndex][0][1] : vertices[batchIndex][2][1],
                              vertices[batchIndex][0][0] : vertices[batchIndex][1][0]]
        
        # plt.imshow(batchMask.detach().numpy())
        # #plt.imshow(featuresMask)
        # plt.show()
        
        flat = torch.flatten(batchMask)
        flat = flat[flat > absoluteMaskThreshold]

        medianValue, _ = torch.median(flat, dim=0)
        medianValue    = medianValue.item()

        stdValue = 0
        diff = torch.pow(flat - medianValue, 2)
        stdValue = torch.sqrt((1 / (diff.shape[0] - 1)) * torch.sum(diff, dim=0)).item()
        
        # dont use gaussian Blur on raw neural network output mask, it operation can connect different masks with bridges and will give worse results
        minThreshold = medianValue - stdValue * 3
        #maxThreshold = medianValue + stdValue #not in use

        batchMask[batchMask < minThreshold]  = 0
        batchMask[batchMask >= minThreshold] = 255
        batchMask = batchMask.detach().numpy()
        batchMask = np.uint8(batchMask)

        batchMask   = cv.GaussianBlur(batchMask, (31, 31), 1.0)
        _, thresh   = cv.threshold(batchMask, 127, 255, 0)
        contours, _ = cv.findContours(thresh, cv.RETR_TREE, cv.CHAIN_APPROX_SIMPLE)
        c = max(contours, key = cv.contourArea)
        filledContour = np.zeros_like(batchMask)
        cv.fillPoly(filledContour, pts =[c], color=(255,255,255))
        batchMask = filledContour
        batchMasks.append(batchMask)


        heatmap = pred_featuresSeg[batchIndex]

        featuresMask = np.zeros((heatmap.shape[1], heatmap.shape[2]), dtype=np.uint8)

        maxTemperature, _ = torch.max(heatmap, dim=0)
        for y in range(featuresMask.shape[0]):
            for x in range(featuresMask.shape[1]):
                # maxTemperature = threshold
                # for classID in range(NUM_CLASSES):
                #     t = heatmap[classID, y, x]
                #     if t > maxTemperature:
                #         maxTemperature = t
                #featuresMask[y, x] = 255 if maxTemperature > 0 else 0
                featuresMask[y, x] = 255 if maxTemperature[y, x] > minutiaesThreshold else 0

        # plt.imshow(batchMask)
        # #plt.imshow(featuresMask)
        # plt.show()


        features = []
        contours, _ = cv.findContours(featuresMask, cv.RETR_LIST, cv.CHAIN_APPROX_NONE)


        for contour in contours:
            M = cv.moments(contour)
            if M["m00"] == 0:
                continue
            
            x = int(M["m10"] / M["m00"])
            y = int(M["m01"] / M["m00"])

            vecX, vecY = 0, 0
            count = 0
            for k in range(MINUTIAES_CLASSES):
                t = heatmap[k, y, x]
                if t > minutiaesThreshold:
                    anglesRad = 2 * math.pi * (k + 0.5) / MINUTIAES_CLASSES
                    vecX += math.cos(anglesRad) * t
                    vecY += math.sin(anglesRad) * t
                    count += 1
            if count == 0:
                continue
            vecX /= count
            vecY /= count

            angle = math.atan2(vecY, vecX)
            features.append((x - vertices[batchIndex][0][0], y - vertices[batchIndex][0][1], angle))
            # think to maxRadius or radius for every point (for matching, when points and images blended)
        
        batchFeatures.append(features)
    
    maxSize = (maxWidth, maxHeight)
    
    return batchFeatures, batchMasks, vertices, maxSize




if __name__ == '__main__':
    model = FeatureExtractionUNet(n_channels=INPUT_CHANNELS, n_featuresClasses=MINUTIAES_CLASSES, n_maskClasses=MASK_CLASSES, features=64)
    load_checkpoint('./models/checkpoint495_touchless.pth', model)


    IMAGES_FOLDER = "./stitching_test/23/"
    #IMAGES_FOLDER = "./stitching_test/-1/"
    #IMAGES_FOLDER = "./HQ_result/"
    imagePaths = [join(IMAGES_FOLDER, name) for name in listdir(IMAGES_FOLDER) if isfile(join(IMAGES_FOLDER, name))]
    imagePaths = sorted(imagePaths)

    imagesList = []
    for i, imagePath in enumerate(imagePaths):
        image = cv.imread(imagePath, cv.IMREAD_GRAYSCALE)
        #image = cv.resize(image, (image.shape[1] // 2, image.shape[0]//2))
        #image = cv.adaptiveThreshold(image, 255, cv.ADAPTIVE_THRESH_MEAN_C, cv.THRESH_BINARY,5,2)
        #image = cv.GaussianBlur(image, (3, 3), 1, 1)
        # image = cv.medianBlur(image, 3)
        # image = cv.medianBlur(image, 3)
        # image = cv.medianBlur(image, 3)
        #image = cv.GaussianBlur(image, (5, 5), 1, 1)
        
        #plt.imshow(image, cmap='gray')
        #plt.show()
        imagesList.append(image)
    
    features, masks, vertices, maxSize = featureExtraction(model, imagesList)

    fig, ax = plt.subplots(1, len(imagesList))
    for i, f in enumerate(features):
        # print(len(f))
        # for p in f:
        #    cv.circle(imagesList[i], (p[0], p[1]), 6, (255, 255, 255), -1)
        #    cv.circle(imagesList[i], (p[0], p[1]), 3, (0, 0, 0), -1)
        #    cv.line(imagesList[i], (p[0], p[1]), (int(p[0] + 10*math.cos(p[2])), int(p[1] + 10*math.sin(p[2]))), (0, 0, 0), 2)
        ax[i].imshow(imagesList[i], cmap='gray')
    
    #plt.show()

    triangles = []
    for i, f in enumerate(features):
        ex = TriangleExtractor(f)
        triangles.append(ex.extractedTriangles)
        f = np.array(f)

        indexes = []
        for tri in ex.extractedTriangles:
            indexes.append(tri.indexes)
        indexes = np.array(indexes)
        ax[i].triplot(f[:, 0], f[:, 1], indexes)

    plt.show()


    numImages = len(imagesList)
    Homographies            = [[None for x in range(numImages)] for y in range(numImages)]
    InverseHomographies     = [[None for x in range(numImages)] for y in range(numImages)]
    MatchedTrianglesCount   = [[0    for x in range(numImages)] for y in range(numImages)]
    MatchedTrianglesIndexes = [[None for x in range(numImages)] for y in range(numImages)]

    for i in range(numImages):
        #bi = borders[i]
        for j in range(i + 1, numImages):
            #bj = borders[j]
            matcher = TrianglesMatcher(features[i], triangles[i], features[j], triangles[j], keepOnlyOneBiggestStructure=True, returnTriangles=True)

            print("Matched triangles: ", matcher.numTriangles)
            if matcher.numTriangles < 6:
                continue
            #if abs(np.linalg.det(matcher.homographyMatrix)) < 0.5: #or abs(np.linalg.det(matcher.inverseHomographyMatrix)) < 0.5:
                #continue
            Homographies[i][j]            = matcher.homographyMatrix
            InverseHomographies[i][j]     = matcher.inverseHomographyMatrix
            MatchedTrianglesCount[i][j]   = matcher.numTriangles
            MatchedTrianglesIndexes[i][j] = matcher.trianglesIndexPairs

    
    # print("===============") # Draw Matched Triangles 
    # for i in range(numImages):
    #     for j in range(i + 1, numImages):
    #         if MatchedTrianglesIndexes[i][j] is not None:
    #             fig, ax = plt.subplots(1, 2)
    #             ax[0].imshow(imagesList[i], cmap='gray')
    #             ax[1].imshow(imagesList[j], cmap='gray')

    #             print(MatchedTrianglesIndexes[i][j])
    #             indexes1 = []
    #             indexes2 = []
    #             for structure in MatchedTrianglesIndexes[i][j]:
    #                 for i0, i1 in structure:
    #                     indexes1.append(triangles[i][i0].indexes)
    #                     indexes2.append(triangles[j][i1].indexes)
    #                     # print(triangles[i][i0].indexes)
    #                     # print(triangles[j][i1].indexes)
    #                     # print()
    #                     # i0 = np.array(triangles[i][i0].indexes)
    #                     # i1 = np.array(triangles[j][i1].indexes)
    #             indexes1 = np.array(indexes1)
    #             indexes2 = np.array(indexes2)
    #             print(indexes1)
    #             print(indexes1.dtype)
    #             fi = np.array(features[i])
    #             fj = np.array(features[j])
    #             print(fi.shape)
    #             ax[0].triplot(fi[:, 0], fi[:, 1], indexes1, color="black", linewidth=4)
    #             ax[0].triplot(fi[:, 0], fi[:, 1], indexes1, color="white", linewidth=1)
    #             ax[1].triplot(fj[:, 0], fj[:, 1], indexes2, color="black", linewidth=4)
    #             ax[1].triplot(fj[:, 0], fj[:, 1], indexes2, color="white", linewidth=1)
    #             plt.show()
    # print("===============")

    # calculate max matchable triangles for 'k' image
    K = 0
    maxSum = 0
    for k in range(numImages):
        sum = 0
        for i in range(1, k+1):
            sum += MatchedTrianglesCount[k - i][k]
        for j in range(1, numImages - k):
            sum += MatchedTrianglesCount[k][k + j]
        if sum > maxSum:
            maxSum = sum
            K = k
    #################################################
    
    print(end="  \t")
    for j in range(numImages):
        print(j, end='\t')
    print()
    for i in range(numImages):
        print(i, end=" \t")
        for j in range(numImages):
            if (j > i):
                print(MatchedTrianglesCount[i][j], end='\t')
            else:
                print(' ', end='\t')
        print()


    MatchedTrianglesCountNotOriented = MatchedTrianglesCount.copy()
    for i in range(numImages):
        for j in range(0, i):
            MatchedTrianglesCountNotOriented[i][j] = MatchedTrianglesCountNotOriented[j][i]

    for i in range(numImages):
        for j in range(numImages):
            print(MatchedTrianglesCountNotOriented[i][j], end='\t')
        print()
    print("base: ", K)
    print()


    paths = maximumValuePath(MatchedTrianglesCountNotOriented, numImages, K)
    for p in paths:
        print(p)
    TransformedHomography = [None] * numImages
    TransformedPoints     = [None] * numImages
    for i, p in enumerate(paths):
        N = len(p)
        if N == 0:
            continue
        
        transformationMatrix = np.identity(3, dtype=np.float32)
        for j in range(N - 1):
            f, t = p[j], p[j+1]
            # if t > f:
            #     transformationMatrix = InverseHomographies[f][t] @ transformationMatrix
            # else:
            #     transformationMatrix = Homographies[t][f] @ transformationMatrix

            # if t > f:
            #     transformationMatrix = Homographies[f][t] @ transformationMatrix
            # else:
            #     transformationMatrix = InverseHomographies[t][f] @ transformationMatrix

            if t > f:
                transformationMatrix = transformationMatrix @ Homographies[f][t]
            else:
                transformationMatrix = transformationMatrix @ InverseHomographies[t][f]

        TransformedHomography[i] = transformationMatrix.copy()

        A = imagesList[p[0]]
        imageWidthA  = A.shape[1]
        imageHeightA = A.shape[0]
        pointsA = np.array([
            (0,           0),
            (imageWidthA, 0),
            (imageWidthA, imageHeightA),
            (0,           imageHeightA),
        ], dtype=np.float32)
        pointsA = pointsA.reshape((-1, 1, 2))
        newPointsA = cv.perspectiveTransform(pointsA, transformationMatrix)

        TransformedPoints[i] = newPointsA

    BaseImage   = imagesList[K]
    imageWidth  = BaseImage.shape[1]
    imageHeight = BaseImage.shape[0]
    pointsBase  = np.array([
        (0,          0),
        (imageWidth, 0),
        (imageWidth, imageHeight),
        (0,          imageHeight),
    ], dtype=np.float32)
    pointsBase = pointsBase.reshape((-1, 1, 2))
    TransformedPoints[K]     = pointsBase
    TransformedHomography[K] = np.identity(3, dtype=np.float32)



    minX =  float('inf')
    maxX = -float('inf')
    minY =  float('inf')
    maxY = -float('inf')
    for i in range(numImages):
        if TransformedPoints[i] is not None:
            bboxMinX, bboxMinY, bboxMaxX, bboxMaxY = bbox(TransformedPoints[i])
            minX = min(bboxMinX, minX)
            minY = min(bboxMinY, minY)
            maxX = max(bboxMaxX, maxX)
            maxY = max(bboxMaxY, maxY)
    
    offsetX = -min(minX, 0)
    offsetY = -min(minY, 0)

    newImageWidth  = int(round(maxX - minX))
    newImageHeight = int(round(maxY - minY))


    distanceMask = [None for _ in range(numImages)]
    WarpedImages = [None for _ in range(numImages)]
    
    translationMatrix = np.identity(3, dtype=np.float32)
    translationMatrix[0, 2] = offsetX
    translationMatrix[1, 2] = offsetY

    imagesToBlend = 0
    borderSize = 1

    fig, ax = plt.subplots(2, numImages)

    for i in range(numImages):
        if TransformedHomography[i] is None:
            continue
        image           = imagesList[i]
        fingerprintMask = masks[i]
        #fingerprintMask = imagesList[i]

        #cv.imshow("image", image)
        #cv.imshow("fingerprintMask", fingerprintMask)

        imageWidth  = image.shape[1]
        imageHeight = image.shape[0]
        points = np.array([
            (0,          0),
            (imageWidth, 0),
            (imageWidth, imageHeight),
            (0,          imageHeight),
        ], dtype=np.float32)
        points = points.reshape((-1, 1, 2))

        newTransformationMatrix = TransformedHomography[i] @ translationMatrix
        transformedPoints = cv.perspectiveTransform(points, newTransformationMatrix)


        # mask = np.zeros((newImageHeight, newImageWidth), dtype=np.uint8)
        # transformedPoints = transformedPoints.astype(np.int32)
        # cv.fillPoly(mask, [transformedPoints], (255, 255, 255))
        # mask = cv.copyMakeBorder(mask, borderSize, borderSize, borderSize, borderSize, cv.BORDER_CONSTANT, None, (0,0,0))
        # distanceMask[i] = cv.distanceTransform(mask, cv.DIST_L1, cv.DIST_MASK_3)
        # cv.normalize(distanceMask[i], distanceMask[i], 0.0, 1.0, cv.NORM_MINMAX)

        fingerprintMask = cv.copyMakeBorder(fingerprintMask, borderSize, borderSize, borderSize, borderSize, cv.BORDER_CONSTANT, None, (0,0,0))
        #dist = cv.distanceTransform(fingerprintMask, cv.DIST_L1, cv.DIST_MASK_PRECISE)
        dist = cv.distanceTransform(fingerprintMask, cv.DIST_L1, cv.DIST_MASK_PRECISE)
        cv.normalize(dist, dist, 0.0, 1.0, cv.NORM_MINMAX)

        dist = dist[borderSize:dist.shape[0]-borderSize,borderSize:dist.shape[1]-borderSize]
        # print(dist.shape)
        for y in range(dist.shape[0]):
            for x in range(dist.shape[1]):
                if dist[y, x] > 0:
                    dist[y, x] = 2.71 ** (dist[y, x]) - 1
        #cv.imshow("dist", dist)
        distanceMask[i] = cv.warpPerspective(dist, newTransformationMatrix, (newImageWidth, newImageHeight))

        WarpedImages[i] = cv.warpPerspective(image, newTransformationMatrix, (newImageWidth, newImageHeight))

        ax[0, i].imshow(WarpedImages[i], cmap='gray')
        ax[1, i].imshow(distanceMask[i], cmap='gray')

        #cv.imshow("distanceMask", distanceMask[i])
        #cv.imshow("WarpedImages", WarpedImages[i])
        #cv.waitKey(0)
        imagesToBlend += 1
    plt.show()



#     ################################################################################################################################################################
#     for i in range(numImages):
#         if TransformedHomography[i] is None or i == K:
#             continue
        
#         imageWidth  = WarpedImages[i].shape[0]
#         imageHeight = WarpedImages[i].shape[1]

#         result, fx, fy = alignImagesUsingOpticalFlow(WarpedImages[i], WarpedImages[K])



#         fig, ax = plt.subplots(1, 5)

#         ax[0].imshow(WarpedImages[i], cmap='gray')
#         ax[1].imshow(WarpedImages[K], cmap='gray')
#         ax[2].imshow(result, cmap='gray')

#         imageWidth  = result.shape[1]
#         imageHeight = result.shape[0]

#         print(imageWidth, imageHeight)

#         skip = 6
#         newWidth  = imageWidth  // skip
#         newHeight = imageHeight // skip

#         x, y = np.meshgrid(np.linspace(0, newWidth,  newWidth),
#                         np.linspace(0, newHeight, newHeight))
        

#         u = np.zeros((newWidth * newHeight))
#         v = np.zeros((newWidth * newHeight))

#         print(newHeight, newWidth)
#         for i in range(newHeight - 1):
#             for j in range(newWidth - 1):
#                 yy = (newHeight - i - 1) * skip
#                 xx = j * skip
#                 u[i * newWidth + j] = fx[yy, xx] #x
#                 v[i * newWidth + j] = fy[yy, xx] #y
        
        
#         # Plotting Vector Field with QUIVER 
#         ax[3].quiver(x, y, u, v, color='black', scale_units='xy', scale=25) 
#         #plt.title('Vector Field') 
        
#         # # Setting x, y boundary limits 
#         # ax[1].xlim(0, imageWidth) 
#         # ax[1].ylim(0, imageHeight) 
        
#         # Show plot with grid 
#         ax[3].grid()

#         lengths = np.sqrt(fx * fx  + fy * fy)
#         ax[4].imshow(lengths)

#         plt.show() 

#         # fig, ax = plt.subplots(1, 3)
#         # ax[0].imshow(WarpedImages[i])
#         # ax[1].imshow(WarpedImages[K])
#         # ax[2].imshow(result)
#         # plt.show()
# ################################################################################################################################################################################################


    #distanceMask[K] *= 2

    print("images to Blend = ", imagesToBlend)

    print("image Size = ", newImageHeight, newImageWidth)

    # fig, ax = plt.subplots(1, 3)
    # ax[0].imshow(WarpedImages[0], cmap='gray')
    # ax[1].imshow(WarpedImages[1], cmap='gray')
    # ax[2].imshow(WarpedImages[2], cmap='gray')
    # plt.show()

    outputImage = np.zeros((newImageHeight, newImageWidth), dtype=np.uint8)
    for i in range(newImageHeight):
        for j in range(newImageWidth):
            coefs = [0] * numImages
            sum = 0
            for k in range(numImages):
                if distanceMask[k] is None:
                    continue
                coefs[k] = distanceMask[k][i, j]
                if coefs[k] >= 0.0000001:
                    sum += coefs[k]
            
            color = 0
            for k in range(numImages):
                if WarpedImages[k] is None:
                    continue
                color += coefs[k] * float(WarpedImages[k][i, j])

            color /= sum
            if sum > 0.0000001:
                outputImage[i, j] = int(color)
    
    plt.imshow(outputImage, cmap='gray')
    plt.show()



    # for i in range(numImages):
    #     for j in range(i + 1, numImages):
    #         if MatchedTrianglesCount[i][j] >= 4 and Homographies[i][j] is not None:
    #             blending(imagesList[i], imagesList[j], Homographies[i][j])