import cv2 as cv
import numpy as np


# mask = np.zeros((256, 256), dtype=np.uint8)

# points = [
#     (50,  50),
#     (200, 50),
#     (200, 200),
#     (50,  200)
# ]

# points = np.array(points)

# points = points.reshape((-1, 1, 2))

# cv.fillPoly(mask, [points], 255)


# dist = cv.distanceTransform(mask, cv.DIST_L1, 3)
# cv.normalize(dist, dist, 0, 1.0, cv.NORM_MINMAX)

# cv.imshow("image", dist)
# cv.waitKey(0)


# def BFS_paths(graph : list, N, startIndex):
#     queue = [startIndex]
#     used = [False] * N

#     while len(queue) > 0:
#         index = queue.pop()
#         used[index] = True

#         for i in range(N):
#             if graph[index][i] != 0 and used[i] == False:
#                 queue.append(i)
        

def bbox(points):
    points2D = points.reshape(-1, 2)
    minX =  float('inf')
    maxX = -float('inf')
    minY =  float('inf')
    maxY = -float('inf')
    for i in range(points2D.shape[0]):
        x = points2D[i, 0]
        y = points2D[i, 1]
        if minX > x:
            minX = x
        if maxX < x:
            maxX = x
        if minY > y:
            minY = y
        if maxY < y:
            maxY = y
    return minX, minY, maxX, maxY


def blending(image1, image2, homographyMatrix):
    points1 = [
        (0,               0),
        (image1.shape[1], 0),
        (image1.shape[1], image1.shape[0]),
        (0,               image1.shape[0]),
    ]
    points1 = np.array(points1, dtype=np.float32)
    points1 = points1.reshape((-1, 1, 2))

    points2 = [
        (0,               0),
        (image2.shape[1], 0),
        (image2.shape[1], image2.shape[0]),
        (0,               image2.shape[0]),
    ]
    points2 = np.array(points2, dtype=np.float32)
    points2 = points2.reshape((-1, 1, 2))

    newPoints1 = cv.perspectiveTransform(points1, homographyMatrix)

    minX =  10000
    maxX = -10000
    minY =  10000
    maxY = -10000
    for i in range(points2.shape[0]):
        x = points2[i, 0, 0]
        y = points2[i, 0, 1]
        if (minX > x):
            minX = x
        if (maxX < x):
            maxX = x
        if (minY > y):
            minY = y
        if (maxY < y):
            maxY = y
    
    for i in range(newPoints1.shape[0]):
        x = newPoints1[i, 0, 0]
        y = newPoints1[i, 0, 1]
        if (minX > x):
            minX = x
        if (maxX < x):
            maxX = x
        if (minY > y):
            minY = y
        if (maxY < y):
            maxY = y
    
    #print(minX, minY, maxX, maxY)

    newImageWidth  = int(round(maxX - minX))
    newImageHeight = int(round(maxY - minY))

    offsetX = -min(minX, 0)
    offsetY = -min(minY, 0)

    #translationMatrix = np.zeros((2, 3), dtype=np.float32)
    translationMatrix = np.identity(3, dtype=np.float32)
    translationMatrix[0, 2] = offsetX
    translationMatrix[1, 2] = offsetY
    #print(translationMatrix)
    
    newHomography = homographyMatrix @ translationMatrix
    newPoints1 = cv.perspectiveTransform(points1, newHomography)
    newPoints1 = np.int32(newPoints1)
    newPoints2 = cv.perspectiveTransform(points2, translationMatrix)
    newPoints2 = np.int32(newPoints2)
    

    #exclude distanceTransform values calculations from borders
    mask1 = np.zeros((newImageHeight, newImageWidth), dtype=np.uint8)
    cv.fillPoly(mask1, [newPoints1], 255)
    mask1 = cv.copyMakeBorder(mask1, 1, 1, 1, 1, cv.BORDER_CONSTANT, None, (0,0,0))
    dist1 = cv.distanceTransform(mask1, cv.DIST_L1, 3)
    cv.normalize(dist1, dist1, 0, 1.0, cv.NORM_MINMAX)

    mask2 = np.zeros((newImageHeight, newImageWidth), dtype=np.uint8)
    cv.fillPoly(mask2, [newPoints2], 255)
    mask2 = cv.copyMakeBorder(mask2, 1, 1, 1, 1, cv.BORDER_CONSTANT, None, (0,0,0))
    dist2 = cv.distanceTransform(mask2, cv.DIST_L1, 3)
    cv.normalize(dist2, dist2, 0, 1.0, cv.NORM_MINMAX)
    ox, oy = 1, 1

    warpedImage1 = cv.warpPerspective(image1, newHomography, (newImageWidth, newImageHeight))
    warpedImage2 = cv.warpAffine(image2, translationMatrix[:2, :], (newImageWidth, newImageHeight))


    output = np.zeros((newImageHeight, newImageWidth), dtype=np.uint8)
    for i in range(newImageHeight):
        for j in range(newImageWidth):
            coef1 = 0
            coef2 = 0
            if dist1[i+oy, j+ox] > 0.00001:
                coef1 = dist1[i+oy, j+ox]
            if dist2[i+oy, j+ox] > 0.00001:
                coef2 = dist2[i+oy, j+ox]

            if coef1 + coef2 <= 0.000001:
                continue
            
            color1 = warpedImage1[i, j]
            color2 = warpedImage2[i, j]
            output[i, j] = (color1 * coef1 + color2 * coef2) / (coef1 + coef2)


    cv.imshow("dist1", dist1)
    cv.imshow("dist2", dist2)

    cv.imshow("output", output)

    cv.imshow("warpedImage1", warpedImage1)
    cv.imshow("warpedImage2", warpedImage2)
    cv.waitKey(0)
    # print(points1)
    # print(newPoints1)






