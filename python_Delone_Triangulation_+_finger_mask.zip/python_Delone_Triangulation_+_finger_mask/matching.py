import scipy
from scipy.spatial import Delaunay
from scipy.sparse.csgraph import connected_components
from scipy.sparse import csr_matrix

import math
import numpy as np

import cv2 as cv

class Triangle:
    def __init__(self, indexes, edges, edgesLengthsCoef, innerAngles):
        self.indexes          = indexes
        self.edges            = edges
        self.edgesLengthsCoef = edgesLengthsCoef
        self.innerAngles      = innerAngles


class TriangleExtractor:
    def __init__(self, points : list):
        self.points = points
        self.triangles = []

        coordinates = []
        for x, y, a in self.points:
            coordinates.append((x, y))

        triangles = Delaunay(coordinates)
        self.extractedTriangles = []
        for tri in triangles.simplices:
            triplet = self.__orderingTriplet(tri)
            self.extractedTriangles.append(self.__denoteTriangle(triplet))

    
    def __clockwiseAngle(self, point1, point2, point3):
        x1 = point1[0] - point2[0]
        y1 = point1[1] - point2[1]
        x2 = point3[0] - point2[0]
        y2 = point3[1] - point2[1]

        dot = x1 * x2 + y1 * y2
        det = x1 * y2 - x2 * y1
        return math.atan2(det, dot)
    
    def __angleBetweenTwoVectors(self, i0, i1, i2):
        x1 = self.points[i0][0] - self.points[i1][0]
        y1 = self.points[i0][1] - self.points[i1][1]
        x2 = self.points[i2][0] - self.points[i1][0]
        y2 = self.points[i2][1] - self.points[i1][1]
        return math.acos((x1 * x2 + y1 * y2) / (math.sqrt(x1**2 + y1**2) * math.sqrt(x2**2 + y2**2)))



    # clockwise ordering around center, along OY axis
    def __orderingTriplet(self, indexes : list):
        centerX = 0
        centerY = 0
        for i in indexes:
            centerX += self.points[i][0]
            centerY += self.points[i][1]
        centerX /= len(indexes)
        centerY /= len(indexes)

        angles = []
        for i in indexes:
            x1 = self.points[i][0] - centerX
            y1 = self.points[i][1] - centerY
            x2 = 0
            y2 = 1

            dot = x1 * x2 + y1 * y2
            det = x1 * y2 - x2 * y1
            angle = math.atan2(det, dot)

            if angle < 0:
                angle += math.pi
            angles.append(angle)
        order = [i[0] for i in sorted(enumerate(angles), key=lambda x:x[1])]
        return [indexes[i] for i in order]


    def __distance(self, index1, index2):
        return math.sqrt((self.points[index1][0] - self.points[index2][0])**2 + \
                         (self.points[index1][1] - self.points[index2][1])**2)

    def __denoteEdge(self, index1, index2):
        length = self.__distance(index1, index2)

        x1 = self.points[index1][0]
        y1 = self.points[index1][1]
        a1 = self.points[index1][2]

        x2 = self.points[index2][0]
        y2 = self.points[index2][1]
        a2 = self.points[index2][2]

        p1 = (math.cos(a1) + x1, math.sin(a1) + y1)
        p2 = (math.cos(a2) + x2, math.sin(a2) + y2)
        
        theta1 =  self.__clockwiseAngle(p1, self.points[index1], self.points[index2])
        theta2 = -self.__clockwiseAngle(p2, self.points[index2], self.points[index1])

        return (theta1, theta2, length)
    

    # denote triangle from triplet
    def __denoteTriangle(self, indexes : list):
        index1 = indexes[0]
        index2 = indexes[1]
        index3 = indexes[2]

        edges = [
            self.__denoteEdge(index1, index2),
            self.__denoteEdge(index2, index3),
            self.__denoteEdge(index3, index1),
        ]

        lengths = [edges[i][2] for i in range(len(edges))]
        order = [i[0] for i in sorted(enumerate(lengths), key=lambda x:x[1])]

        edgesLengthsCoef = [
            lengths[order[0]] / lengths[order[2]], # delete first  min length by maximum
            lengths[order[1]] / lengths[order[2]], # delete second min length by maximum
        ]

        innerAngles = [
            math.cos(self.__angleBetweenTwoVectors(index3, index1, index2)),
            math.cos(self.__angleBetweenTwoVectors(index1, index2, index3)),
            math.cos(self.__angleBetweenTwoVectors(index2, index3, index1))
        ]
        return Triangle(indexes, edges, edgesLengthsCoef, innerAngles)
    


class TrianglesMatcher:
    def __init__(self, points1 : list, triangles1 : list, points2 : list, triangles2 : list, offset1=(0, 0), offset2=(0,0), \
                       minutiaeAngleThreshold=15, innerAngleThreshold=15, lengthsCoefThreshold=0.2, minStructureTriangeCount=3, keepOnlyOneBiggestStructure=True, \
                       returnTriangles=False):
    
        self.minutiaeAngleThreshold = minutiaeAngleThreshold * math.pi / 180
        self.innerAngleThreshold    = innerAngleThreshold    * math.pi / 180
        self.lengthsCoefThreshold   = lengthsCoefThreshold
        self.trianglesIndexPairs    = None

        RMP = []
        for i in range(len(triangles1)):
            triangle1 = triangles1[i]
            for j in range(len(triangles2)):
                triangle2 = triangles2[j]
                # indexesShift
                for shift in range(3):
                    count = 0
                    for k in range(3):
                        edge1        = triangle1.edges[k]                       # size = 3
                        angles1      = triangle1.innerAngles[k]                 # size = 3
                        lengthsCoef1 = triangle1.edgesLengthsCoef               # size = 2

                        edge2        = triangle2.edges[(k + shift) % 3]         # size = 3
                        angles2      = triangle2.innerAngles[(k + shift) % 3]   # size = 3
                        lengthsCoef2 = triangle2.edgesLengthsCoef               # size = 2

                        if (abs(edge1[0] - edge2[0]) < self.minutiaeAngleThreshold and \
                            abs(edge1[1] - edge2[1]) < self.minutiaeAngleThreshold and \
                            abs(angles1 - angles2)   < self.innerAngleThreshold    and \
                            abs(lengthsCoef1[0] - lengthsCoef2[0]) < self.lengthsCoefThreshold and \
                            abs(lengthsCoef1[1] - lengthsCoef2[1]) < self.lengthsCoefThreshold):
                            count += 1
                    if count == 3:
                        RMP.append((i, j, shift))
                        break # we can check all variants of shift for every pair of triangles


        matrix1 = np.zeros((len(points1), len(points1)), dtype=np.uint32)
        matrix2 = np.zeros((len(points2), len(points2)), dtype=np.uint32)

        for i, j, shift in RMP:
            ids1 = triangles1[i].indexes

            matrix1[ids1[0], ids1[1]] = 1
            matrix1[ids1[1], ids1[0]] = 1

            matrix1[ids1[1], ids1[2]] = 1
            matrix1[ids1[2], ids1[1]] = 1

            matrix1[ids1[2], ids1[0]] = 1
            matrix1[ids1[0], ids1[2]] = 1


            ids2 = triangles2[j].indexes
            matrix2[ids2[0], ids2[1]] = 1
            matrix2[ids2[1], ids2[0]] = 1
            
            matrix2[ids2[1], ids2[2]] = 1
            matrix2[ids2[2], ids2[1]] = 1

            matrix2[ids2[2], ids2[0]] = 1
            matrix2[ids2[0], ids2[2]] = 1
        
        graph = csr_matrix(matrix1)
        _, labels = connected_components(csgraph=graph, directed=False, return_labels=True)
        trueLabelIds1 = dict()
        for i in range(len(labels)):
            if labels[i] not in trueLabelIds1:
                trueLabelIds1[labels[i]] = [i]
            else:
                trueLabelIds1[labels[i]].append(i)
        
        _trueLabelIds1 = dict()
        componentIndex = 0
        for key, value in trueLabelIds1.items():
            if len(value) != 1:
                for v in value:
                    _trueLabelIds1[v] = componentIndex
                componentIndex += 1
        trueLabelIds1 = _trueLabelIds1
        
        graph = csr_matrix(matrix2)
        _, labels = connected_components(csgraph=graph, directed=False, return_labels=True)
        trueLabelIds2 = dict()
        for i in range(len(labels)):
            if labels[i] not in trueLabelIds2:
                trueLabelIds2[labels[i]] = [i]
            else:
                trueLabelIds2[labels[i]].append(i)
        
        _trueLabelIds2 = dict()
        componentIndex = 0
        for key, value in trueLabelIds2.items():
            if len(value) != 1:
                for v in value:
                    _trueLabelIds2[v] = componentIndex
                componentIndex += 1
        trueLabelIds2 = _trueLabelIds2

        componentRMP = dict()
        for i, j, shift in RMP:
            indexes1 = triangles1[i].indexes
            indexes2 = triangles2[j].indexes

            componentPair = (trueLabelIds1[indexes1[0]], trueLabelIds2[indexes2[0]])
            if componentPair not in componentRMP:
                componentRMP[componentPair] = [(i, j)]
            else:
                componentRMP[componentPair].append((i, j))

        componentRMP = {k: v for k, v in sorted(componentRMP.items(), key=lambda item: len(item[1]), reverse=True)}
        if keepOnlyOneBiggestStructure:
            temp = dict()
            for k, v in componentRMP.items():
                temp[k] = v
                break
            componentRMP = temp
        keys = list(componentRMP.keys())

        srcPoints = []
        dstPoints = []

        self.numTriangles = 0
        for key in keys:
            rmp = componentRMP[key]
            if len(rmp) < minStructureTriangeCount:
                break
            
            for i0, i1 in rmp:
                triangleCenter1 = [0, 0]
                triangleCenter2 = [0, 0]
                for i in range(3):
                    triangleCenter1[0] += points1[triangles1[i0].indexes[i]][0]
                    triangleCenter1[1] += points1[triangles1[i0].indexes[i]][1]

                    triangleCenter2[0] += points2[triangles2[i1].indexes[i]][0]
                    triangleCenter2[1] += points2[triangles2[i1].indexes[i]][1]
                srcPoints.append((triangleCenter1[0] / 3 + offset1[0], triangleCenter1[1] / 3 + offset1[1]))
                dstPoints.append((triangleCenter2[0] / 3 + offset2[0], triangleCenter2[1] / 3 + offset2[1]))
                self.numTriangles += 1

        self.homographyMatrix = None
        self.inverseHomographyMatrix = None

        if (len(srcPoints) < 4 or len(dstPoints) < 4):
            return
        
        srcPoints = np.array(srcPoints)
        dstPoints = np.array(dstPoints)
        self.homographyMatrix, _        = cv.findHomography(srcPoints, dstPoints, cv.RANSAC)#, 5.0)
        self.inverseHomographyMatrix, _ = cv.findHomography(dstPoints, srcPoints, cv.RANSAC)#, 5.0)

        if returnTriangles == True:
            self.trianglesIndexPairs = []
            for key in keys:
                rmp = componentRMP[key]
                if len(rmp) < minStructureTriangeCount:
                    break
                
                triangleStructure = []
                for i0, i1 in rmp:
                    triangleStructure.append((i0, i1))
                self.trianglesIndexPairs.append(triangleStructure)

