from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import minimum_spanning_tree


def BFS_paths(graph : list, N, startIndex):
    queue = [startIndex]
    used = [False] * N
    values = [-100000] * N

    p = [-1] * N
    while len(queue) > 0:
        index = queue.pop()
        used[index] = True

        for i in range(N):
            if values[i] < graph[index][i] and graph[index][i] != 0 and used[i] == False:
                queue.append(i)
                p[i] = index
                values[i] = graph[index][i]

    paths = [[] for _ in range(N)]
    for i in range(N):
        if p[i] == -1:
            continue
        
        paths[i].append(i)
        to = p[i]
        while to != startIndex:
            v = p[to]
            paths[i].append(to)
            to = v
        paths[i].append(startIndex)
    return paths


def maximumValuePath(graph : list, N : int, startIndex : int):
    _graph = graph.copy()

    inversedValues = _graph.copy()

    maxValue = -1
    for i in range(N):
        for j in range(N):
            if inversedValues[i][j] > maxValue:
                maxValue = inversedValues[i][j]

    for i in range(N):
        for j in range(N):
            if inversedValues[i][j] > 0:
                inversedValues[i][j] = maxValue - inversedValues[i][j] + 1


    X = csr_matrix(inversedValues)
    Tcsr = minimum_spanning_tree(X)
    MST = (Tcsr.toarray().astype(int))



    _graph = [[0 for x in range(N)] for y in range(N)] 

    for i in range(N):
        for j in range(N):
            if MST[i][j] != 0:
                _graph[i][j] = maxValue - MST[i][j] + 1
                _graph[j][i] = maxValue - MST[i][j] + 1

    print('===================')
    for i in range(N):
        for j in range(N):
            print(_graph[i][j], end=',\t')
        print()
    print()
    print('===================')


    return BFS_paths(_graph, N, startIndex)


if __name__ == '__main__':
    numVertices = 9
    # graph = [
    #     [0, 5, 8, 0, 0],
    #     [0, 0, 0, 4, 0],
    #     [0, 0, 0, 6, 11],
    #     [0, 0, 0, 0, 0],
    #     [0, 0, 0, 0, 0],
    # ]

    # graph = [
    #     [0, 11, 0],
    #     [0, 0, 10],
    #     [0, 0,  0],
    # ]

    # for i in range(numVertices):
    #     for j in range(0, i):
    #         graph[i][j] = graph[j][i]

    graph = [
        [0,       12,      12,      10,      6,       0,       6,       0,       0],
        [12,      0,       14,      6,       30,      0,       0,       9,       0],
        [12,      14,      0,       6,       0,       0,       0,       15,      0],
        [10,      6,       6,       0,       0,       0,       22,      0,       0],
        [6,       30,      0,       0,       0,       0,       0,       0,       0],
        [0,       0,       0,       0,       0,       0,       0,       0,       0],
        [6,       0,       0,       22,      0,       0,       0,       6,       0],
        [0,       9,       15,      0,       0,       0,       6,       0,       0],
        [0,       0,       0,       0,       0,       0,       0,       0,       0],
    ]


    paths = maximumValuePath(graph=graph, N=numVertices, startIndex=1)

    for p in paths:
        print(p)