import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt

import os
from os import listdir
from os.path import join, isfile, isdir

from skimage.restoration import denoise_wavelet, estimate_sigma

import scipy
import math

def localOrientationMap(image : cv.Mat, smooth_sigma = 8):
    SobelX = cv.Sobel(image, cv.CV_32FC1, 1, 0)
    SobelY = cv.Sobel(image, cv.CV_32FC1, 0, 1)
    
    Gxx = SobelX * SobelX
    Gyy = SobelY * SobelY
    Gxy = SobelX * SobelY
    
    Gxx = scipy.ndimage.filters.gaussian_filter(Gxx, smooth_sigma)
    Gxy = scipy.ndimage.filters.gaussian_filter(Gxy, smooth_sigma)
    Gyy = scipy.ndimage.filters.gaussian_filter(Gyy, smooth_sigma)
            
    angles = math.pi/2. + np.divide(np.arctan2(np.multiply(Gxy,2), np.subtract(Gxx,Gyy)),2)
    return angles



if __name__ == '__main__':

    IMAGES_PATH = './HQ/'
    RESULT_PATH = './HQ_result/'

    files = [join(IMAGES_PATH, file) for file in listdir(IMAGES_PATH) if isfile(join(IMAGES_PATH, file))]
    for file in files:
        sourceImage = cv.imread(file, cv.IMREAD_GRAYSCALE)
        
        flat1 = sourceImage.copy()
        flat1 = np.reshape(flat1, -1)

        #clahe = cv.createCLAHE(clipLimit=5)
        #finalImage = clahe.apply(sourceImage)

        #sourceImage = finalImage.copy()


        # fig, ax = plt.subplots(1, 4)

        # ax[0].hist(flat1, bins=256)



        # ax[1].imshow(finalImage, cmap='gray')

        
        # flat2 = finalImage.copy()
        # flat2 = np.reshape(flat2, -1)

        # ax[2].hist(flat2, bins=256)


        # finalImage[finalImage < 105 ] = 0
        # finalImage[finalImage > 105 ] = 255

        # ax[3].imshow(finalImage, cmap='gray')

        # plt.show()

        imageWidth  = sourceImage.shape[1]
        imageHeight = sourceImage.shape[0]

        sourceImage = cv.resize(sourceImage, (imageWidth // 2, imageHeight // 2))

        imageWidth  = sourceImage.shape[1]
        imageHeight = sourceImage.shape[0]
        

        blurred = cv.GaussianBlur(sourceImage, (25, 25), 0.0)

        result = np.zeros_like(sourceImage, dtype=np.uint8)

        result = 128 + sourceImage - blurred
        result[result < 0] = 0
        result[result > 255] = 255


        # for i in range(imageHeight):
        #     for j in range(imageWidth):
        #         value = 128 + sourceImage[i, j] - blurred[i, j]
        #         if value < 0:
        #             value = 0
        #         elif value > 255:
        #             value = 255
        #         result[i, j] = value
        
        #cv.imshow("result", result)
        # cv.waitKey(0)
                

        minImage = sourceImage.copy()
        maxImage = sourceImage.copy()

        blockSize = 8
        minThreshold = int(0.2 * (1 + 2 * blockSize) * (1 + 2 * blockSize))
        maxThreshold = int(0.3 * (1 + 2 * blockSize) * (1 + 2 * blockSize))

        
        for y in range(blockSize, imageHeight - blockSize):
            for x in range(blockSize, imageWidth - blockSize):
                levels = [0] * 256 #num grayscale pixel values
                for dy in range(-blockSize, blockSize+1, 1):
                    for dx in range(-blockSize, blockSize+1, 1):
                        levels[sourceImage[y + dy, x + dx]] += 1
                
                minValue = 0
                minSum = 0
                while minValue < 255:
                    minSum += levels[minValue]
                    if (minSum >= minThreshold):
                        break
                    minValue += 1
                
                maxValue = 255
                maxSum = 0
                while maxValue > 0:
                    maxSum += levels[maxValue]
                    if maxSum >= maxThreshold:
                        break
                    maxValue -= 1

                minImage[y, x] = minValue
                maxImage[y, x] = maxValue

        #cv.imshow("maxImage", maxImage)
        #cv.imshow("minImage", minImage)
        # cv.waitKey(0)

        result2 = np.zeros_like(sourceImage, dtype=np.uint8)

        for i in range(imageHeight):
            for j in range(imageWidth):
                valueSource = sourceImage[i, j]
                valueMin    = minImage[i, j]
                valueMax    = maxImage[i, j]

                if (valueMax <= valueMin):
                    valueMin -= 1
                
                value = 0
                if valueSource > valueMin:
                    if valueSource < valueMax:
                        value = (valueSource - valueMin) * 255 / (valueMax - valueMin)
                    else:
                        value = 255
                
                result2[i, j] = value


        # result2 = cv.GaussianBlur(result2, (3, 3), 0)
        result2 = cv.blur(result2, (2, 2))
        
        # result2 = cv.medianBlur(result2, 3)


        name = file[file.rfind('/')+1:]

        #cv.imshow("result2", result2)
        cv.imwrite(join(RESULT_PATH, name), result2)
        print(join(RESULT_PATH, name))
        #cv.waitKey(0)
        




# if __name__ == '__main__':

#     #sourceImage = cv.imread("./fingerimage/finger7.png", cv.IMREAD_GRAYSCALE)
#     sourceImage = cv.imread("./HQ/2.png", cv.IMREAD_GRAYSCALE)

#     cv.imshow("sourceImage", sourceImage)

#     imageWidth  = sourceImage.shape[1]
#     imageHeight = sourceImage.shape[0]

#     blurred = cv.GaussianBlur(sourceImage, (25, 25), 0.0)

#     result = np.zeros_like(sourceImage, dtype=np.uint8)

#     result = 128 + sourceImage - blurred
#     result[result < 0] = 0
#     result[result > 255] = 255


#     # for i in range(imageHeight):
#     #     for j in range(imageWidth):
#     #         value = 128 + sourceImage[i, j] - blurred[i, j]
#     #         if value < 0:
#     #             value = 0
#     #         elif value > 255:
#     #             value = 255
#     #         result[i, j] = value
    
#     cv.imshow("result", result)
#     # cv.waitKey(0)
            

#     minImage = sourceImage.copy()
#     maxImage = sourceImage.copy()

#     blockSize = 8
#     minThreshold = int(0.2 * (1 + 2 * blockSize) * (1 + 2 * blockSize))
#     maxThreshold = int(0.3 * (1 + 2 * blockSize) * (1 + 2 * blockSize))

    
#     for y in range(blockSize, imageHeight - blockSize):
#         for x in range(blockSize, imageWidth - blockSize):
#             levels = [0] * 256 #num grayscale pixel values
#             for dy in range(-blockSize, blockSize+1, 1):
#                 for dx in range(-blockSize, blockSize+1, 1):
#                     levels[sourceImage[y + dy, x + dx]] += 1
            
#             minValue = 0
#             minSum = 0
#             while minValue < 255:
#                 minSum += levels[minValue]
#                 if (minSum >= minThreshold):
#                     break
#                 minValue += 1
            
#             maxValue = 255
#             maxSum = 0
#             while maxValue > 0:
#                 maxSum += levels[maxValue]
#                 if maxSum >= maxThreshold:
#                     break
#                 maxValue -= 1

#             minImage[y, x] = minValue
#             maxImage[y, x] = maxValue

#     cv.imshow("maxImage", maxImage)
#     cv.imshow("minImage", minImage)
#     # cv.waitKey(0)

#     result2 = np.zeros_like(sourceImage, dtype=np.uint8)

#     for i in range(imageHeight):
#         for j in range(imageWidth):
#             valueSource = sourceImage[i, j]
#             valueMin    = minImage[i, j]
#             valueMax    = maxImage[i, j]

#             if (valueMax <= valueMin):
#                 valueMin -= 1
            
#             value = 0
#             if valueSource > valueMin:
#                 if valueSource < valueMax:
#                     value = (valueSource - valueMin) * 255 / (valueMax - valueMin)
#                 else:
#                     value = 255
            
#             result2[i, j] = value


#     result2 = cv.medianBlur(result2, 3)
#     result2 = cv.GaussianBlur(result2, (5, 5), 0)



#     cv.imshow("result2", result2)
#     cv.imwrite("result2.png", result2)
#     cv.waitKey(0)